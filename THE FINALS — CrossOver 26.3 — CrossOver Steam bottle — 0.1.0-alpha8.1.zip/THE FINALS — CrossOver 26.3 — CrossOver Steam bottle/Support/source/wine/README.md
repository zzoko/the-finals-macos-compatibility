# Stable CrossOver bottle: corresponding Wine source

wine-modified-source.tar.xz contains the complete modified Wine tree for this route, derived from CodeWeavers crossover-sources-26.3.0.tar.gz (SHA-256 ac99c8ca4b3848f3e81784135f023df266b61c2345726ea55a50b3e030dd6872). The five adjacent patches describe the changes in the order recorded in build-recipe.json. The archive already contains them; do not apply them twice. Wine licenses, authors and modification notices are retained in the archive and ../../licenses.

The Unix NTDLL includes THE FINALS-specific GS/TLS selection, executable-memory registration and occupied-host-region search. Discovery.exe and the standalone probe name opt in; unrelated processes retain the original PE. The CPU entry shim is scoped separately.

The bottle PE is the exact rebuilt Wine PE inherited from ARC alpha7. Its complete corresponding source is unchanged: the only source difference is the game selector in Unix loader.c, which is compiled into the newly rebuilt Unix NTDLL. The installed vendor PE is retained as ntdll-stock.dll. This route does not use a NotProton PE or bridge.

Run zsh rebuild.zsh NEW_OUTPUT_DIRECTORY with Apple clang/SDK, modern Bison and the x86_64 MinGW toolchain listed in build-recipe.json. It builds both Unix and PE NTDLL, strips debug data and preserves the required Unix RPATHs. Compiler, timestamp and signature metadata may change hashes; validate new outputs before making new guarded deltas. Recipients need no build tools.

The recipe records exact source hashes, output hashes, compiler versions and source provenance. Support/manifest-bottle.tsv is authoritative for installed inputs/outputs. Re-run the compatibility probes and route-specific launcher/game tests for changed binaries.
