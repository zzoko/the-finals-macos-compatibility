# Compatibility additions and rebuild instructions

This folder contains the source for our helper, Wine entry shim, ARM child loader
and CPU correction payload. `compatibility/cpu/LICENSE` retains the MIT license
from rosettax87_jit commit `a44f1eff28591a90f4a8c7297134294811da06b5`.
The payload preserves the tested x86 NT flag semantics. It does not modify game
or anti-cheat binaries, suppress checks, or replace their results.

The target family is Apple Silicon/macOS 27.x. The unchanged CPU correction uses
Rosetta ABI `0x16f0200000000` and guarded offsets/instructions. The installer checks these
components directly and exercises CPU behavior before activating a launcher;
it does not reject a Mac solely for having a different macOS build number.
Developer Tools authorization is required during the loader's brief child setup;
the loader detaches before Windows execution. No system Rosetta file is changed.

## Rebuild our additions

Install Xcode Command Line Tools and CMake. From this folder, choose a fresh build
directory outside the extracted package:

```sh
finals_build="$HOME/Library/Caches/finals-compat-build"
cmake -S compatibility/cpu -B "$finals_build/cpu" -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_ARCHITECTURES=arm64
cmake --build "$finals_build/cpu" --target runtime_loader libRuntimeRosettax87 -j4
clang -arch x86_64 -O2 -Wall -Wextra -Werror compatibility/cpu/nt_lab/wine-entry.c -o "$finals_build/wine"
codesign --force --sign - "$finals_build/wine"
clang -arch x86_64 -dynamiclib -O2 -Wall -Wextra -Werror compatibility/finals-regions.c -o "$finals_build/finals-regions.dylib"
codesign --force --sign - "$finals_build/finals-regions.dylib"
```

CMake signs the ARM loader and preserves the payload's required 16 KiB segment
alignment. The payload itself is intentionally unsigned and mapped by the loader.
The Wine shim needs the paired preserved real Wine executable, named
`wine-nt-original`, and `ARC_NT_WINE_DIR` pointing to their directory. Preserve the
vendor's entitlements plus those recorded in `compatibility/wine-entitlements.plist`
when signing that private executable. Do not replace the installed CrossOver app.
`ARC_NT_USE_AOT=1` is required for the tested performance profile.

Preview uses the helper and a separately selected `ntdll-arc.dll`. Recreate that
sibling with `python3 compatibility/patch-preview-tls.py /absolute/private/CrossOver`
using exactly one of the guarded original inputs. The script preserves the vendor
PE and checks both its hash and target bytes. Do not remove guards for newer builds.

Stable 26.3 integrates the GS/executable-memory and occupied-region fixes into a
rebuilt Unix NTDLL. Its complete corresponding modified Wine source, five patches,
PE recipes and compiler instructions are in `wine/` in the stable downloads.
The shared `compatibility/search.h` provides the tested occupied-region search
algorithm; the stable Wine source uses it as `arc_host_search.h`.

## Installer compatibility checks

`preflight/hostcheck.cpp` is a read-only Mach-O/ABI checker. It mirrors the entry
signatures, export version and patterns consumed by the unchanged CPU loader,
including its fixed emitter/flag/far-return locations. It does not write Apple
files or grant authorization. `cpu-check.zsh` creates an isolated temporary Wine
prefix, runs the three bundled Windows tests and removes only that temporary
prefix. It preserves existing Steam/game sessions. `bounded-run.c` bounds each
test's own process group; reports stay in the user's Library/Logs folder.

Build the checker with `clang++ -std=c++17 -O2 -arch arm64 -mmacosx-version-min=14.0
hostcheck.cpp -o hostcheck`, and the supervisor with the same flags using `clang`
and `bounded-run.c`. Build each of ntflag.c, ntwincontext.c and ntchild.c using
`x86_64-w64-mingw32-gcc -O2 -static INPUT.c -o OUTPUT.exe`. Ad-hoc sign the two
native helpers with `codesign --force --sign - FILE`. Only the developer needs
these build tools; recipients run the bundled files. Their hashes are embedded
in the installer, so regenerate packages after any checker change.

The live setup offers an administrator dialog for DevToolsSecurity only after
the user explicitly agrees; system authorization is not silently enabled.
Preflight is a compatibility test, not proof of universal macOS 27 gameplay.

## Releasing an update

Runtime inputs and outputs are listed in `../manifest-*.tsv` and dependencies in
`../dependencies-*.tsv`; installed files are checked by a complete runtime receipt.
The installer applies BSDIFF40 deltas with macOS `bspatch`. The NotProton launch
adapter reconstructs its script from the recipient's exact local shim using a
guarded delta. Its pinned hash is an interface guard, not an app-version check.

Fresh compiler/SDK/signature metadata can change output hashes. Re-run the CPU,
exception, syscall, child-process, GS/TLS and allocator behavior checks before a
game trial; do not declare a new binary equivalent merely because it builds.
Use a new package version, regenerate deltas/manifests and their embedded hash
guards, exercise install/verify/update/rollback/removal, then regenerate both
archive and per-file checksums. Keep previous versions outside the active package.
The package README records the gameplay status of its own launch route.
Preserve the distinction between installer tests and actual gameplay validation.

THE FINALS selection is Discovery.exe; runtime_probe.exe is the standalone test name. Other process names use the paired original Wine CPU path. Internal ARC_* names are inherited compatibility interfaces.
