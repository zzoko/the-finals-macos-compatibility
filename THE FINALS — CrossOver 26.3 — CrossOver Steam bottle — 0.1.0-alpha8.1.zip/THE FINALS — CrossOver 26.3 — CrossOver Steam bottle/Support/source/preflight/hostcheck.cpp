// Read-only Rosetta ABI checks for the unchanged ARC CPU correction.
// No macOS build-number allowlist and no modification of Apple files.
#include <mach-o/loader.h>
#include <mach/machine.h>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

struct Image {
    std::vector<unsigned char> bytes;
    std::vector<segment_command_64> segments;
    std::vector<section_64> sections;
    template<class T> T get(uint64_t at) const {
        if (at > bytes.size() || sizeof(T) > bytes.size() - at)
            throw std::runtime_error("Truncated Rosetta image");
        T v; std::memcpy(&v, bytes.data() + at, sizeof(v)); return v;
    }
    explicit Image(const char *path) {
        std::ifstream f(path, std::ios::binary);
        if (!f) throw std::runtime_error(std::string("Cannot read Rosetta component: ") + path);
        bytes.assign(std::istreambuf_iterator<char>(f), {});
        auto h = get<mach_header_64>(0);
        if (h.magic != MH_MAGIC_64 || h.cputype != CPU_TYPE_ARM64 ||
            h.sizeofcmds > bytes.size() - sizeof(h))
            throw std::runtime_error("Unexpected Rosetta Mach-O format");
        uint64_t pos = sizeof(h), end = pos + h.sizeofcmds;
        for (uint32_t i = 0; i < h.ncmds; ++i) {
            auto cmd = get<load_command>(pos);
            if (cmd.cmdsize < sizeof(cmd) || pos > end || cmd.cmdsize > end - pos)
                throw std::runtime_error("Invalid Rosetta load command");
            if (cmd.cmd == LC_SEGMENT_64) {
                auto seg = get<segment_command_64>(pos);
                if (cmd.cmdsize < sizeof(seg) || seg.nsects > (cmd.cmdsize - sizeof(seg))/sizeof(section_64) ||
                    seg.fileoff > bytes.size() || seg.filesize > bytes.size() - seg.fileoff)
                    throw std::runtime_error("Invalid Rosetta segment");
                segments.push_back(seg);
                for (uint32_t j=0;j<seg.nsects;++j) {
                    auto s = get<section_64>(pos+sizeof(seg)+j*sizeof(section_64));
                    if ((s.flags & SECTION_TYPE) != S_ZEROFILL &&
                        (s.offset > bytes.size() || s.size > bytes.size()-s.offset))
                        throw std::runtime_error("Invalid Rosetta section");
                    sections.push_back(s);
                }
            }
            pos += cmd.cmdsize;
        }
        if (pos != end) throw std::runtime_error("Unexpected Rosetta command extent");
    }
    uint64_t fileAt(uint64_t vm, uint64_t size) const {
        for (auto s:segments)
            if (vm >= s.vmaddr && vm-s.vmaddr <= s.filesize && size <= s.filesize-(vm-s.vmaddr))
                return s.fileoff + vm - s.vmaddr;
        throw std::runtime_error("Rosetta address is outside mapped file data");
    }
    uint64_t pattern(const char *name,const char *text) const {
        std::istringstream in(text);std::string token;std::vector<int> p;
        while(in>>token) p.push_back(token=="?" ? -1 : std::stoi(token,nullptr,16));
        for(size_t i=0;i+p.size()<=bytes.size();++i) {
            bool match=true;
            for(size_t j=0;j<p.size();++j)if(p[j]>=0 && bytes[i+j]!=p[j]){match=false;break;}
            if(match) {
                if(bytes.size()-i<64) throw std::runtime_error("Rosetta signature too close to image boundary");
                return i;
            }
        }
        throw std::runtime_error(std::string("Rosetta signature changed: ")+name);
    }
    void words(uint64_t vm,std::initializer_list<uint32_t> expected,const char *name) const {
        auto at=fileAt(vm,expected.size()*4);
        for(auto word:expected) {
            if(get<uint32_t>(at)!=word)throw std::runtime_error(std::string("Rosetta entry changed: ")+name);
            at+=4;
        }
    }
};

int main(int argc,char **argv) {
    try {
        const char *rp="/usr/libexec/rosetta/runtime";
        const char *lp="/Library/Apple/usr/libexec/oah/libRosettaRuntime";
        if(argc==4 && std::string(argv[1])=="--inspect-files"){rp=argv[2];lp=argv[3];}
        else if(argc!=1)throw std::runtime_error("Usage: hostcheck [--inspect-files runtime library]");
        Image r(rp),l(lp);
        r.pattern("exportsFetch","62 06 40 F9 63 12 40 B9");
        r.pattern("svcCall","B0 18 80 D2 01 10 00 D4 E1 37 9F 9A C0 03 5F D6");
        auto aot=r.pattern("disableAot","FD 43 07 91 E4 2B 00 F9");
        auto adrp=r.get<uint32_t>(aot+8),ldrb=r.get<uint32_t>(aot+12);
        if((adrp&0x9f000000)!=0x90000000 || (ldrb&0xffc00000)!=0x39400000)
            throw std::runtime_error("Rosetta AOT address encoding changed");
        auto cls=r.pattern("classifyArmPc","42 8B 40 F9 21 97 41 B9");
        if((r.get<uint32_t>(cls+12)&0xfc000000)!=0x94000000)
            throw std::runtime_error("Rosetta classification call changed");
        r.pattern("sysCsrctl","70 3C 80 D2 01 10 00 D4 01 00 80 92 20 20 80 9A C0 03 5F D6");
        l.pattern("transactionResultSize","01 4D 80 52");
        l.pattern("translateInsn","FF 43 03 D1 FC 6F 07 A9 FA 67 08 A9 F8 5F 09 A9 F6 57 0A A9 F4 4F 0B A9 FD 7B 0C A9 FD 03 03 91 F3 03 00 AA");
        auto dec=l.pattern("decodeOpcode","E2 ? 08 91 E3 ? 08 91 E1 03 ? ?");
        if((l.get<uint32_t>(dec+12)&0xfc000000)!=0x94000000)
            throw std::runtime_error("Rosetta opcode decoder call changed");
        l.pattern("defaultFreeGPRMask","00 94 08 F8 A7 52 68 12 02 B9 68 1A 42 B9");
        bool exports=false;
        for(auto s:l.sections) if(!std::strncmp(s.segname,"__DATA",16) && !std::strncmp(s.sectname,"exports",16)) {
            if(s.size<40 || l.get<uint64_t>(s.offset)!=0x16f0200000000ULL)
                throw std::runtime_error("Rosetta internal ABI version changed; a port is required");
            auto pointer=l.get<uint64_t>(s.offset+8)&0xffffffffULL;
            l.fileAt(pointer,8); // The unchanged loader uses this image's identity VM/file mapping.
            if(l.fileAt(pointer,8)!=pointer)throw std::runtime_error("Rosetta export mapping changed");
            auto init=l.get<uint64_t>(pointer)&0xffffffffULL;
            l.fileAt(init,4);
            exports=true;
        }
        if(!exports)throw std::runtime_error("Rosetta export table missing");
        l.words(0x18a0,{0xa9be4ff4,0xa9017bfd,0x910043fd,0xaa0103f4},"emitter");
        r.words(0x198b8,{0xd342fc28,0xd341fc29,0x3100041f,0x5280504a},"to-flags");
        r.words(0x1992c,{0xd342fc08,0xd344fc09,0xd34bfc0a,0xd3689c0b},"from-flags");
        l.words(0x18f3c,{0xa9ba6ffc,0xa90167fa,0xa9025ff8,0xa90357f6},"far-return");
        std::puts("Rosetta component checks passed. CPU behavior will be checked before activation.");
        return 0;
    } catch(const std::exception &e) {
        std::fprintf(stderr,"Compatibility check: %s\n",e.what());return 1;
    }
}
