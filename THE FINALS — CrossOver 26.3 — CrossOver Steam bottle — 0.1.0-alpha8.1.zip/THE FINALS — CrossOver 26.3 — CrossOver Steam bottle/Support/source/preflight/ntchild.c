/* Tests genuine NT state in Wine parent/child processes; no game dependencies. */
#include <windows.h>
#include <stdio.h>
#include <stdint.h>
static int check(void) {
    uint64_t old,got;
    __asm__ volatile("pushfq; pop %0":"=r"(old));
    uint64_t set=old|0x4000;
    __asm__ volatile("push %1; popfq; pushfq; pop %0; push %2; popfq":"=r"(got):"r"(set),"r"(old):"cc","memory");
    printf("NT process %lu requested=%llx observed=%llx\n",GetCurrentProcessId(),set,got);
    return !(got&0x4000);
}
int main(int argc,char **argv) {
    setbuf(stdout,NULL);unsigned failed=check();
    if(argc>1)return failed;
    char path[MAX_PATH],command[2*MAX_PATH];GetModuleFileNameA(NULL,path,sizeof(path));
    for(int i=0;i<2;i++) {
        snprintf(command,sizeof(command),"\"%s\" child",path);
        STARTUPINFOA si={.cb=sizeof(si)};PROCESS_INFORMATION pi={};
        if(!CreateProcessA(NULL,command,NULL,NULL,FALSE,0,NULL,NULL,&si,&pi)){printf("CreateProcess failed %lu\n",GetLastError());return 2;}
        if(WaitForSingleObject(pi.hProcess,20000)!=WAIT_OBJECT_0){puts("child timed out");return 2;}
        DWORD status=1;GetExitCodeProcess(pi.hProcess,&status);failed+=status!=0;
        CloseHandle(pi.hProcess);CloseHandle(pi.hThread);
    }
    printf("child propagation failed_groups=%u\n",failed);return failed?1:0;
}
