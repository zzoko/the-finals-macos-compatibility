/* Host virtual-address search; no Windows API result or protection is altered. */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <errno.h>
#include <sys/mman.h>

typedef void *(*arc_try_fn)(void *, size_t, int, void *);
typedef bool (*arc_region_fn)(uintptr_t, uintptr_t *, uintptr_t *, void *);
struct arc_search_stats { uint64_t attempts, queries, skipped; };

static void *arc_search(uintptr_t base, uintptr_t end, ptrdiff_t step,
                       uintptr_t start, size_t size, int prot,
                       arc_try_fn attempt, arc_region_fn region, void *ctx,
                       struct arc_search_stats *stats)
{
    const uintptr_t stride = step < 0 ? 0-(uintptr_t)step : (uintptr_t)step;
    while (start && start >= base && start <= end && size <= end-start)
    {
        if (stats) stats->attempts++;
        if (attempt((void *)start,size,prot,ctx) != MAP_FAILED) return (void *)start;
        if (errno != EEXIST) return NULL;
        if (!stride) break;
        uintptr_t distance = step > 0 ? end-start : start-base;
        if (stride > distance) break;
        uintptr_t count = 1, lo=0, hi=0;
        if (stats) stats->queries++;
        /* The query can race a host unmap. A skipped region was occupied when
         * observed; the actual allocation still uses a non-overwriting kernel
         * operation. Query failure or a non-overlap falls back to one step. */
        int saved_errno = errno;
        if (region && region(start,&lo,&hi,ctx) && hi>lo && hi>start && lo<start+size)
        {
            uintptr_t delta;
            if (step > 0) delta=hi-start;
            else
            {
                if (lo < size) { errno=saved_errno; break; }
                delta=start-(lo-size);
            }
            count=delta/stride + (delta%stride != 0);
            if (!count) count=1;
        }
        errno=saved_errno;
        if (count > distance/stride) break;
        if (stats) stats->skipped += count-1;
        start = step > 0 ? start+count*stride : start-count*stride;
    }
    return NULL;
}
