.text
.p2align 2
.globl _nt_pop,_nt_pop_end,_nt_push,_nt_push_end
_nt_pop:
    ldrh w22,[x4]
    ubfx w22,w22,#14,#1
    bfi x17,x22,#5,#1
_nt_pop_end:
_nt_push:
    ldrh w22,[x4]
    ubfx x23,x17,#5,#1
    bfi w22,w23,#14,#1
    strh w22,[x4]
_nt_push_end:
.p2align 4
.globl _nt_original_translate,_nt_original_to_flags,_nt_original_from_flags
_nt_original_translate:
    .space 32
_nt_original_to_flags:
    .space 32
_nt_original_from_flags:
    .space 32
.globl _nt_original_far_ret
_nt_original_far_ret:
    .space 32
