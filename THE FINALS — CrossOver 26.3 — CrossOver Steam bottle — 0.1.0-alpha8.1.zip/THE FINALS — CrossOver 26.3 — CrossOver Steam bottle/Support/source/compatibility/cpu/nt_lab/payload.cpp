// Build-specific x86 NT CPU-semantics correction for a private Wine runtime.
// Preserves guest NT across POPF/PUSHF, contexts and 64-bit IRET.
// Does not alter application checks, results or security state.
#include <stdint.h>

extern "C" {
void (*nt_emit_word)(void *,uint32_t)=nullptr;
}
extern "C" int64_t nt_original_translate(void *,void *,void *,int64_t,int64_t);
extern "C" uint64_t nt_original_to_flags(uint64_t,uint64_t);
extern "C" void nt_original_from_flags(uint64_t,uint64_t *,uint64_t *);
extern "C" void nt_original_far_ret(void *,void *,int);
extern "C" const uint32_t nt_pop[],nt_pop_end[],nt_push[],nt_push_end[];

static void emit(void *result,const uint32_t *first,const uint32_t *last) {
    // Use Rosetta's own emitter so an empty/full buffer grows with the original
    // allocator. Direct writes were valid in small probes but not every block.
    while(first!=last)nt_emit_word((char *)result+0x10,*first++);
}
extern "C" int64_t nt_translate(void *result,void *block,void *insns,
                                int64_t count,int64_t index) {
    uint16_t opcode=*(uint16_t *)((char *)insns+index*0x50+4);
    if(opcode>=0x4e && opcode<=0x50)emit(result,nt_pop,nt_pop_end);
    int64_t r=nt_original_translate(result,block,insns,count,index);
    if(opcode>=0x52 && opcode<=0x54)emit(result,nt_push,nt_push_end);
    return r;
}
extern "C" void nt_far_ret(void *result,void *terminator,int single_step) {
    const auto *t=(const uint8_t *)terminator;
    // Far-return IR: byte 1 is operand width (3 = 64 bits), byte 2
    // distinguishes RETF (0) from IRET (1/2). Check before consuming its frame.
    if(t[1]==3 && t[2]!=0) {
        const uint32_t check[]={0x36280051,0xd4200060}; // tbz w17,#5,+8; brk #3 = #GP(0)
        emit(result,check,check+2);
    }
    nt_original_far_ret(result,terminator,single_step);
}
extern "C" uint64_t nt_to_flags(uint64_t nzcv,uint64_t packed) {
    return nt_original_to_flags(nzcv,packed)|((packed&0x20)<<9);
}
extern "C" void nt_from_flags(uint64_t flags,uint64_t *nzcv,uint64_t *packed) {
    nt_original_from_flags(flags,nzcv,packed);
    *packed=(*packed&~0x20ULL)|((flags>>9)&0x20);
}
__attribute__((used,section("__DATA,nt_hooks")))
static const uintptr_t hooks[]={
    0x4e544c4142303031ULL,
    (uintptr_t)nt_translate,(uintptr_t)nt_to_flags,(uintptr_t)nt_from_flags,(uintptr_t)nt_far_ret,
    (uintptr_t)nt_original_translate,(uintptr_t)nt_original_to_flags,
    (uintptr_t)nt_original_from_flags,(uintptr_t)nt_original_far_ret,
    (uintptr_t)&nt_emit_word
};
extern "C" __attribute__((used)) void start() {}
