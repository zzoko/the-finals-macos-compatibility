#!/bin/zsh
emulate -LR zsh
setopt ERR_EXIT NO_UNSET PIPE_FAIL
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
umask 077
[[ $# == 1 ]] || exit 2
runtime=${1:A}; here=${0:A:h}
[[ -x $runtime/lib/wine/x86_64-unix/wine && -x $runtime/bin/wineserver ]] || exit 2
scratch=$(/usr/bin/mktemp -d /private/tmp/finals-compat-check.XXXXXXXX)
logdir="$HOME/Library/Logs/THE FINALS Compatibility"
/bin/mkdir -p "$logdir"
log=$(/usr/bin/mktemp "$logdir/compatibility-check.XXXXXXXX")
typeset -a envs=(HOME="$HOME" PATH="$PATH" TMPDIR="$scratch" WINEPREFIX="$scratch/prefix"
 CX_ROOT="$runtime" CX_HOME="$HOME/Library/Application Support/CrossOver"
 WINEDLLPATH="$runtime/lib/wine/x86_64-windows:$runtime/lib/wine/x86_64-unix"
 WINESERVER="$runtime/bin/wineserver" WINELOADER="$runtime/lib/wine/x86_64-unix/wine"
 WINEDEBUG=-all WINEDLLOVERRIDES='mscoree,mshtml=' WINEMSYNC=0
 DYLD_FALLBACK_LIBRARY_PATH="$runtime/lib/x86_64:$runtime/lib64"
 CX_GRAPHICS_BACKEND=d3dmetal ARC_NT_USE_AOT=1
 ARC_NT_WINE_DIR="$runtime/lib/wine/x86_64-unix" ROSETTA_ADVERTISE_AVX=0)
if [[ -f $runtime/lib/arc-preview/finals-regions.dylib ]]; then
 envs+=(ARC_PREVIEW_CODE_REGIONS=1 ARC_PREVIEW_NTDLL_PATH="$runtime/lib/wine/x86_64-windows/ntdll-arc.dll"
 ARC_NT_LAB_TARGET_DYLD="$runtime/lib/arc-preview/finals-regions.dylib"
 CX_APPLEGPTK_LIBD3DSHARED_PATH="$runtime/lib/apple_gptk/external/libd3dshared.dylib"
 D3DMETAL_FRAMEWORK_PATH="$runtime/lib/apple_gptk/external/D3DMetal.framework/D3DMetal")
else
 envs+=(ARC_NATIVE_CODE_REGIONS=1 CX_APPLEGPTK_LIBD3DSHARED_PATH="$runtime/lib64/apple_gptk/external/libd3dshared.dylib")
fi
cleanup() {
 /usr/bin/env -i "${envs[@]}" "$here/bounded-run" 10 "$runtime/bin/wineserver" -k >> "$log" 2>&1 || true
 [[ $scratch == /private/tmp/finals-compat-check.* && -d $scratch && ! -L $scratch ]] && /bin/rm -rf -- "$scratch"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
print -r -- 'Checking CPU compatibility in an isolated temporary prefix…'
{
 /usr/bin/sw_vers
 /usr/bin/shasum -a 256 /usr/libexec/rosetta/runtime /Library/Apple/usr/libexec/oah/libRosettaRuntime
 print -r -- "runtime=$runtime"
} > "$log"
for probe in ntflag ntwincontext ntchild; do
 /bin/cp "$here/$probe.exe" "$scratch/runtime_probe.exe"
 print -r -- "test=$probe" >> "$log"
 if ! /usr/bin/env -i "${envs[@]}" "$here/bounded-run" 120 "$runtime/lib/wine/x86_64-unix/wine" "$scratch/runtime_probe.exe" >> "$log" 2>&1; then
  print -u2 -r -- "CPU compatibility test failed ($probe). The launcher has not been activated. Details: $log"
  exit 1
 fi
 /usr/bin/env -i "${envs[@]}" "$here/bounded-run" 10 "$runtime/bin/wineserver" -k >> "$log" 2>&1 || true
done
print -r -- 'CPU behavior passed: NT flags, syscalls, exceptions, IRET and child processes.'
print -r -- "Compatibility report: $log"
