// Game-scoped structural AIR correction. No external programs or shader assets.
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#import <objc/runtime.h>
#include <CommonCrypto/CommonDigest.h>
#include <crt_externs.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <unistd.h>
#include "structural.h"

typedef id (*FinalsLibraryMethod)(id, SEL, dispatch_data_t, NSError **) __attribute__((ns_returns_retained));
static FinalsLibraryMethod original_library;
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
static FILE *log_file;
static NSMutableDictionary<NSString *, id> *cache;
static NSMutableSet<NSString *> *reported;
static size_t cached_bytes;
static unsigned rejected_logs;

static void log_message(const char *format, ...) {
    if (!log_file) return;
    pthread_mutex_lock(&mutex);
    va_list args; va_start(args,format); fprintf(log_file,"pid=%d ",getpid());
    vfprintf(log_file,format,args); fputc('\n',log_file); fflush(log_file); va_end(args);
    pthread_mutex_unlock(&mutex);
}
static void digest(const void *bytes, size_t size, char out[65]) {
    uint8_t hash[32]; static const char hex[]="0123456789abcdef";
    CC_SHA256(bytes,(CC_LONG)size,hash);
    for(unsigned i=0;i<32;++i){out[i*2]=hex[hash[i]>>4];out[i*2+1]=hex[hash[i]&15];}out[64]=0;
}
static BOOL discovery_process(void) {
    char **args=*_NSGetArgv();
    for(int i=0;i<*_NSGetArgc();++i){
        const char *base=args[i];for(const char *p=base;*p;++p)if(*p=='/'||*p=='\\')base=p+1;
        size_t n=strlen(base);if(n>=4&&!strcasecmp(base+n-4,".exe"))return !strcasecmp(base,"Discovery.exe");
    }
    return NO;
}
static void remember(NSString *key,id result) {
    pthread_mutex_lock(&mutex);
    if(!cache[key] && cache.count<16384){
        size_t n=[result isKindOfClass:[NSData class]]?[(NSData *)result length]:0;
        if(n<=8*1024*1024-cached_bytes){cache[key]=result;cached_bytes+=n;}
    }
    pthread_mutex_unlock(&mutex);
}
static id corrected_library(id device, SEL selector, dispatch_data_t input, NSError **error) __attribute__((ns_returns_retained));
static id corrected_library(id device, SEL selector, dispatch_data_t input, NSError **error) {
    @autoreleasepool {
        size_t size=input?dispatch_data_get_size(input):0;
        if(size<96 || size>1024*1024)return original_library(device,selector,input,error);
        const void *bytes=NULL;
        __attribute__((objc_precise_lifetime)) dispatch_data_t map=dispatch_data_create_map(input,&bytes,&size);
        if(!map || !bytes || memcmp(bytes,"MTLB",4))return original_library(device,selector,input,error);
        char hash[65];digest(bytes,size,hash);NSString *key=[NSString stringWithUTF8String:hash];
        pthread_mutex_lock(&mutex);id cached=cache[key];pthread_mutex_unlock(&mutex);
        if(cached==[NSNull null])return original_library(device,selector,input,error);
        NSData *patch=[cached isKindOfClass:[NSData class]]?cached:nil;
        if(!patch){
            void *output=NULL;size_t length=0;char reason[256]={0};
            if(!finals_structural_patch(bytes,size,&output,&length,reason,sizeof reason)){
                remember(key,[NSNull null]);
                if(!strncmp(reason,"candidate rejected:",19)){
                    pthread_mutex_lock(&mutex);BOOL log=rejected_logs++<64;pthread_mutex_unlock(&mutex);
                    if(log)log_message("STRUCTURAL_SKIP original=%s reason=%s; using original",hash,reason);
                }
                return original_library(device,selector,input,error);
            }
            patch=[NSData dataWithBytes:output length:length];free(output);
            if(!patch)return original_library(device,selector,input,error);
            remember(key,patch);
        }
        // dispatch_data retains this block, which retains the immutable patch data.
        NSData *owner=patch;
        dispatch_data_t candidate=dispatch_data_create(patch.bytes,patch.length,dispatch_get_global_queue(QOS_CLASS_DEFAULT,0), ^{ (void)owner; });
        if(!candidate)return original_library(device,selector,input,error);
        id result=original_library(device,selector,candidate,error);
        if(!result){
            log_message("REPLACEMENT_FAILED original=%s; using original",hash);
            pthread_mutex_lock(&mutex);if(cache[key])cache[key]=[NSNull null];pthread_mutex_unlock(&mutex);
            if(error)*error=nil;result=original_library(device,selector,input,error);
            log_message("FALLBACK_ORIGINAL success=%d",result!=nil);return result;
        }
        pthread_mutex_lock(&mutex);BOOL first=![reported containsObject:key];if(first && reported.count<1024)[reported addObject:key];pthread_mutex_unlock(&mutex);
        if(first){char result_hash[65];digest(patch.bytes,patch.length,result_hash);log_message("REPLACE original=%s result=%s mode=structural",hash,result_hash);}
        return result;
    }
}
__attribute__((constructor)) static void initialize_skin_curve(void) {
    @autoreleasepool {
        const char *enabled=getenv("D3DM_FINALS_SKIN_CURVE");if(!enabled||strcmp(enabled,"1")||!discovery_process())return;
        const char *log=getenv("D3DM_FINALS_SKIN_CURVE_LOG");if(log&&*log)log_file=fopen(log,"a");
        cache=[NSMutableDictionary new];reported=[NSMutableSet new];
        id<MTLDevice> device=MTLCreateSystemDefaultDevice();if(!device)return;
        SEL selector=@selector(newLibraryWithData:error:);Class cls=object_getClass(device);Method method=NULL;
        while(cls){unsigned count=0;Method *methods=class_copyMethodList(cls,&count);
            for(unsigned i=0;i<count;++i)if(method_getName(methods[i])==selector)method=methods[i];
            free(methods);if(method)break;cls=class_getSuperclass(cls);
        }
        if(!method)return;
        original_library=(FinalsLibraryMethod)method_getImplementation(method);
        method_setImplementation(method,(IMP)corrected_library);
        log_message("READY mode=structural version=2 hook=%s",class_getName(cls));
    }
}
