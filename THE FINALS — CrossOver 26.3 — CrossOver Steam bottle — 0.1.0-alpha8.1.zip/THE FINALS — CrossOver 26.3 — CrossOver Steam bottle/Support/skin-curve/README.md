# Optional S12 skin correction

Included automatically by the main Install.command. The prebuilt universal library
recognizes the affected curve by its structure, without a GPU-family or shader-hash
allowlist. It redirects the curve lookup to its original constant data in memory;
normal dissolve and visibility decisions remain in place. Unknown or ambiguous
patterns are left unchanged. No game shaders are included or modified on disk.

Users do not need Xcode, Command Line Tools, Python or a compiler for this component.
The binary uses only macOS system libraries. Developers can rebuild with
`build.zsh OUTPUT_DIRECTORY` on a Mac with Xcode Command Line Tools.

This module remains independent of CPU compatibility and can be retired after an
upstream correction is verified. Unrecognized shader patterns remain unchanged.
