#include "structural.h"
#include "curve.hpp"
#include <CommonCrypto/CommonDigest.h>
#include <cstdio>
#include <cstdlib>
using namespace finals;

static uint64_t le(const Bytes &v, size_t offset, unsigned n) {
    require(n <= 8 && offset <= v.size() && n <= v.size() - offset, "container read bounds");
    uint64_t out = 0; for (unsigned i = 0; i < n; ++i) out |= uint64_t(v[offset+i]) << (8*i); return out;
}
static void put(Bytes &v, size_t offset, uint64_t value, unsigned n) {
    require(n <= 8 && offset <= v.size() && n <= v.size() - offset, "container write bounds");
    for (unsigned i = 0; i < n; ++i) v[offset+i] = uint8_t(value >> (8*i));
}
static std::map<std::string, size_t> tags(const Bytes &v, size_t start, size_t end) {
    std::map<std::string, size_t> result;
    require(start <= end && end <= v.size(), "tag section bounds");
    while (start + 4 <= end) {
        std::string tag(reinterpret_cast<const char *>(v.data()+start),4);
        if (tag == "ENDT") { require(start+4 == end, "trailing tag bytes"); return result; }
        require(start + 6 <= end, "tag header bounds"); size_t n = le(v,start+4,2);
        require(n <= end-start-6 && !result.count(tag), "tag length/duplicate"); result[tag] = start+6; start += n+6;
    }
    throw std::runtime_error("missing tag terminator");
}
extern "C" int finals_structural_patch(const void *input, size_t size, void **output,
                                      size_t *output_size, char *reason, size_t reason_size) {
    if (output) *output = nullptr; if (output_size) *output_size = 0;
    bool candidate = false;
    auto report = [&](const char *message) { if (reason && reason_size) std::snprintf(reason,reason_size,"%s",message); };
    try {
        require(input && output && output_size && size >= 88 && size <= MaxBytes, "library size bounds");
        Bytes original(static_cast<const uint8_t *>(input), static_cast<const uint8_t *>(input)+size);
        require(!memcmp(input,"MTLB",4) && le(original,16,8) == size, "metallib header");
        size_t fn = le(original,24,8), fnSize = le(original,32,8), publicAt = le(original,40,8), privateAt = le(original,56,8), bitAt = le(original,72,8), bitSize = le(original,80,8);
        require(fn == 88 && size >= 96 && fnSize <= size-fn-4 && le(original,fn,4) == 1 && le(original,fn+4,4) == fnSize, "single-function container");
        size_t fnEnd = fn+4+fnSize;
        require(fnEnd <= publicAt && publicAt <= privateAt && privateAt <= bitAt && bitAt <= size && bitSize <= size-bitAt, "container section order");
        require(le(original,48,8) == privateAt-publicAt && le(original,64,8) == bitAt-privateAt, "metadata section layout");
        auto f = tags(original,fn+8,fnEnd), extension = tags(original,fnEnd,publicAt);
        for (auto &t : f) require(std::set<std::string>{"NAME","TYPE","HASH","OFFT","VERS","MDSZ","RFLT"}.count(t.first), "unknown function tag");
        for (auto &t : extension) require(std::set<std::string>{"HDYN","RLST","UUID"}.count(t.first), "unknown extension tag");
        auto field = [&](const char *name, size_t length) { require(f.count(name) && le(original,f.at(name)-2,2) == length, "required function tag"); return f.at(name); };
        size_t name = field("NAME",7), kind = field("TYPE",1), hash = field("HASH",32), mdsize = field("MDSZ",8), offt = field("OFFT",24);
        require(!memcmp(original.data()+name,"MainPS\0",7) && original[kind] == 1, "not MainPS fragment");
        for (unsigned i=0;i<24;++i) require(original[offt+i]==0,"nonzero function section offset");
        require(le(original,mdsize,8) == bitSize && bitSize >= 20 && le(original,bitAt,4) == 0x0b17c0de && le(original,bitAt+4,4) == 0 && le(original,bitAt+8,4) == 20, "AIR wrapper");
        size_t rawSize = le(original,bitAt+12,4); require(rawSize <= bitSize-20 && bitSize-20-rawSize < 16, "AIR wrapper size");
        for (size_t i=20+rawSize;i<bitSize;++i) require(original[bitAt+i]==0,"nonzero AIR padding");
        uint8_t digest[32]; CC_SHA256(original.data()+bitAt,CC_LONG(bitSize),digest); require(!memcmp(digest,original.data()+hash,32),"AIR hash mismatch");
        auto tree = parse(original.data()+bitAt+20,rawSize);
        auto roundtrip = serialize(*tree); require(roundtrip.size()==rawSize && !memcmp(roundtrip.data(),original.data()+bitAt+20,rawSize),"AIR round-trip mismatch");
        IR ir(*tree); ir.decode(&candidate); ir.proveAndRewrite();
        Bytes raw = serializeOffsets(*tree), replacement(original.begin()+bitAt, original.begin()+bitAt+20);
        put(replacement,12,raw.size(),4); replacement.insert(replacement.end(),raw.begin(),raw.end());
        replacement.resize((replacement.size()+15)&~size_t(15),0);
        int64_t delta = int64_t(replacement.size())-int64_t(bitSize);
        Bytes result(original.begin(),original.begin()+bitAt);
        put(result,16,uint64_t(int64_t(size)+delta),8); put(result,80,replacement.size(),8); put(result,mdsize,replacement.size(),8);
        CC_SHA256(replacement.data(),CC_LONG(replacement.size()),digest); std::copy(digest,digest+32,result.begin()+hash);
        for (auto &t : extension) if (t.first=="HDYN" || t.first=="RLST") {
            require(le(original,t.second-2,2)==16,"tail offset tag"); uint64_t at=le(original,t.second,8), length=le(original,t.second+8,8);
            require(at>=bitAt+bitSize && at<=size && length<=size-at,"tail section bounds"); put(result,t.second,uint64_t(int64_t(at)+delta),8);
        }
        result.insert(result.end(),replacement.begin(),replacement.end()); result.insert(result.end(),original.begin()+bitAt+bitSize,original.end());
        require(result.size()==uint64_t(int64_t(size)+delta) && result.size()<=2*MaxBytes,"result size");
        void *memory=std::malloc(result.size()); require(memory,"allocation failed"); std::memcpy(memory,result.data(),result.size()); *output=memory; *output_size=result.size(); report("constant-backed 33-float curve proved"); return 1;
    } catch (const std::exception &error) {
        if (reason && reason_size) std::snprintf(reason,reason_size,"%s%s",candidate?"candidate rejected: ":"",error.what());
        return 0;
    }
    catch (...) { report("unrecognized shader"); return 0; }
}
