#pragma once
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
// 1: proved and rewritten; 0: original retained. Caller frees *output on success.
int finals_structural_patch(const void *input, size_t size, void **output,
                            size_t *output_size, char *reason, size_t reason_size);
#ifdef __cplusplus
}
#endif
