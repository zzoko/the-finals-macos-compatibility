// Structural proof for the constant-backed local curve. No shader hash list.
#pragma once
#include "bitstream.hpp"
#include <set>

namespace finals {
struct Type { unsigned code; Words ops; };
struct Value { unsigned type; bool integer = false; int64_t number = 0; int instruction = -1; };
struct Instruction { Node *record; unsigned current, result, type; std::vector<unsigned> refs; size_t order; };
struct IR {
    Node &root, &module;
    std::vector<Type> types;
    std::vector<Value> values;
    std::vector<Instruction> instructions;
    Node *function = nullptr;
    unsigned floatType = UINT32_MAX, arrayType = UINT32_MAX, voidType = UINT32_MAX;
    explicit IR(Node &r) : root(r), module(oneBlock(r, 8)) {}
    const Type &type(unsigned id) const { require(id < types.size(), "type id"); return types[id]; }
    unsigned subtype(unsigned id, uint64_t index = 0) const {
        auto &t = type(id);
        if (t.code == 8) { require(index == 0 && t.ops.size() == 2, "pointer type"); return unsigned(t.ops[0]); }
        if (t.code == 11 || t.code == 12) { require(t.ops.size() == 2 && index < t.ops[0], "aggregate index"); return unsigned(t.ops[1]); }
        if (t.code == 18 || t.code == 20 || t.code == 21) { require(index + 1 < t.ops.size(), "member index"); return unsigned(t.ops[index + 1]); }
        throw std::runtime_error("unsupported aggregate type");
    }
    int addressSpace(unsigned id) const { auto &t = type(id); return t.code == 8 && t.ops.size() == 2 ? int(t.ops[1]) : -1; }
    bool integerType(unsigned id, unsigned width) const { auto &t = type(id); return t.code == 7 && t.ops == Words{width}; }
    unsigned virtualType(unsigned code, Words ops) {
        for (size_t i = 0; i < types.size(); ++i) if (types[i].code == code && types[i].ops == ops) return unsigned(i);
        require(types.size() < 4096, "virtual type budget"); types.push_back({code, std::move(ops)}); return unsigned(types.size() - 1);
    }
    unsigned pointer(unsigned element, unsigned space) { return virtualType(8, {element, space}); }
    const Value &value(unsigned id) const { require(id < values.size(), "value id"); return values[id]; }
    void add(Value v) { require(values.size() < 65536, "value budget"); type(v.type); values.push_back(v); }
    int64_t number(unsigned id) const { auto &v = value(id); require(v.integer, "expected integer constant"); return v.number; }
    unsigned ref(uint64_t encoded, unsigned current) const { require(encoded && encoded <= current, "forward value unsupported"); return current - unsigned(encoded); }
    unsigned pair(const Words &ops, size_t &at, unsigned current) const { require(at < ops.size(), "missing value operand"); unsigned id = ref(ops[at++], current); value(id); return id; }
    static int64_t signedNumber(uint64_t n) { require(n != 1, "minimum signed constant unsupported"); return (n & 1) ? -int64_t(n >> 1) : int64_t(n >> 1); }
    void constants(Node &parent) {
        for (auto &p : parent.items) if (p->kind == Node::Block && p->code == 11) {
            unsigned currentType = UINT32_MAX;
            for (auto *r : records(*p)) {
                if (r->code == 1) { require(r->operands.size() == 1, "constant type record"); currentType = unsigned(r->operands[0]); type(currentType); continue; }
                Value v{currentType};
                if (type(currentType).code == 7 && (r->code == 2 || r->code == 4)) {
                    require(r->code != 4 || r->operands.size() == 1, "integer record");
                    v.integer = true; v.number = r->code == 2 ? 0 : signedNumber(r->operands[0]);
                }
                add(v);
            }
        }
    }
    void decode(bool *candidate = nullptr) {
        bool version2 = false;
        for (auto *r : records(module)) if (r->code == 1 && r->operands == Words{2}) version2 = true;
        require(version2, "unsupported AIR module version");
        for (auto *r : records(oneBlock(module, 17))) if (r->code != 1 && r->code != 19) {
            require(types.size() < 4096, "type budget");
            types.push_back({r->code, r->operands});
            if (r->code == 3) floatType = unsigned(types.size() - 1);
            if (r->code == 2) voidType = unsigned(types.size() - 1);
        }
        require(floatType != UINT32_MAX && voidType != UINT32_MAX, "missing scalar types");
        for (auto &t : types) {
            auto typeID = [&](uint64_t id) { require(id < types.size(), "type reference bounds"); };
            switch (t.code) {
                case 2: case 3: case 4: case 5: case 10: case 16: case 22: require(t.ops.empty(), "scalar type shape"); break;
                case 6: require(t.ops.size() <= 1, "opaque type shape"); break;
                case 7: require(t.ops.size() == 1 && t.ops[0] && t.ops[0] <= 64, "integer type shape"); break;
                case 8: require(t.ops.size() == 2 && t.ops[1] <= 16, "pointer type shape"); typeID(t.ops[0]); break;
                case 11: case 12: require(t.ops.size() == 2 && t.ops[0] && t.ops[0] <= 65536, "array/vector type shape"); typeID(t.ops[1]); break;
                case 18: case 20: case 21:
                    require(t.ops.size() >= (t.code == 21 ? 2u : 1u) && t.ops[0] <= 1, "struct/function type shape");
                    for (size_t i=1;i<t.ops.size();++i) typeID(t.ops[i]); break;
                default: throw std::runtime_error("unsupported type encoding");
            }
        }
        for (size_t i = 0; i < types.size(); ++i) if (types[i].code == 11 && types[i].ops == Words{33, floatType}) { require(arrayType == UINT32_MAX, "ambiguous curve type"); arrayType = unsigned(i); }
        require(arrayType != UINT32_MAX, "no curve array type");
        if (candidate) *candidate = true;
        auto strings = records(oneBlock(root, 23)); require(strings.size() == 1 && strings[0]->code == 1, "string table");
        const auto &str = strings[0]->blob;
        size_t bodyIndex = 0, selectedIndex = SIZE_MAX; unsigned selectedType = UINT32_MAX; bool discard = false;
        for (auto *r : records(module)) {
            if (r->code == 7 || r->code == 9 || r->code == 14 || r->code == 18) throw std::runtime_error("global value layout unsupported");
            if (r->code != 8) continue;
            auto &o = r->operands; require(o.size() >= 5 && o[0] <= str.size() && o[1] <= str.size() - o[0], "function record");
            std::string name(reinterpret_cast<const char *>(str.data() + o[0]), size_t(o[1]));
            unsigned ft = unsigned(o[2]); require(type(ft).code == 21 && type(ft).ops.size() >= 2, "function type");
            add({pointer(ft, 0)});
            if (name == "air.discard_fragment") discard = true;
            if (!o[4]) {
                if (name == "MainPS") { require(selectedIndex == SIZE_MAX, "multiple MainPS definitions"); selectedIndex = bodyIndex; selectedType = ft; }
                ++bodyIndex;
            }
        }
        require(discard && selectedIndex != SIZE_MAX, "not a discard-capable MainPS");
        bodyIndex = 0;
        for (auto &p : module.items) if (p->kind == Node::Block && p->code == 12) { if (bodyIndex++ == selectedIndex) function = p.get(); }
        require(function, "MainPS body"); constants(module);
        auto args = type(selectedType).ops; require(args[0] == 0, "variadic MainPS");
        for (size_t i = 2; i < args.size(); ++i) add({unsigned(args[i])});
        constants(*function);
        size_t order = 0;
        for (auto *r : records(*function)) {
            if (r->code == 1) { require(r->operands.size() == 1 && r->operands[0] <= 4096, "basic block count"); continue; }
            require(instructions.size() < 32768, "instruction budget");
            Instruction in{r, unsigned(values.size()), UINT32_MAX, voidType, {}, order++}; auto &o = r->operands; size_t at = 0;
            auto take = [&]() { unsigned id = pair(o, at, in.current); in.refs.push_back(id); return id; };
            auto finish = [&]() { require(at == o.size(), "unexpected instruction operands"); };
            auto trailing = [&](size_t low, size_t high) { require(o.size() - at >= low && o.size() - at <= high, "instruction shape"); at = o.size(); };
            switch (r->code) {
                case 2: { unsigned a = take(); take(); in.type = value(a).type; trailing(1, 2); break; }
                case 56: { unsigned a = take(); in.type = value(a).type; trailing(1, 2); break; }
                case 3: { take(); require(o.size() - at == 2, "cast shape"); in.type = unsigned(o[at]); type(in.type); at += 2; break; }
                case 6: { unsigned v = take(); take(); require(type(value(v).type).code == 12, "extract vector"); in.type = subtype(value(v).type); break; }
                case 7: { unsigned v = take(); take(); take(); require(type(value(v).type).code == 12, "insert vector"); in.type = value(v).type; break; }
                case 8: { unsigned v = take(); take(); unsigned mask = take(); auto a = type(value(v).type), m = type(value(mask).type); require(a.code == 12 && m.code == 12, "shuffle types"); in.type = virtualType(12, {m.ops[0], a.ops[1]}); break; }
                case 10: { if (!o.empty()) take(); break; }
                case 11: { require(o.size() == 1 || o.size() == 3, "branch shape"); if (o.size() == 3) { at = 2; take(); } else at = 1; break; }
                case 15: break;
                case 16: {
                    require(o.size() >= 3, "phi shape"); in.type = unsigned(o[0]); type(in.type);
                    size_t count = (o.size() - 1) / 2;
                    for (size_t j = 0; j < count; ++j) { int64_t delta = signedNumber(o[1 + 2*j]); int64_t id = int64_t(in.current) - delta; require(id >= 0 && id < 65536, "phi value range"); in.refs.push_back(unsigned(id)); }
                    at = o.size(); break;
                }
                case 19: {
                    require(o.size() == 4 && o[2] < values.size(), "alloca shape"); unsigned element = unsigned(o[0]);
                    if (!(o[3] & 64)) element = subtype(element);
                    in.type = pointer(element, 0); in.refs.push_back(unsigned(o[2])); at = o.size(); break;
                }
                case 20: {
                    unsigned p = take(); require(addressSpace(value(p).type) >= 0, "load pointer");
                    require(o.size() - at == 2 || o.size() - at == 3, "load shape");
                    in.type = o.size() - at == 3 ? unsigned(o[at++]) : subtype(value(p).type); trailing(2, 2); break;
                }
                case 26: {
                    unsigned agg = take(); in.type = value(agg).type; require(at < o.size(), "empty extractvalue");
                    while (at < o.size()) in.type = subtype(in.type, o[at++]); break;
                }
                case 27: { unsigned agg = take(); take(); in.type = value(agg).type; require(at < o.size(), "empty insertvalue"); unsigned check = in.type; while (at < o.size()) check = subtype(check, o[at++]); break; }
                case 28: { unsigned a = take(); take(); unsigned boolean = virtualType(7, {1}); auto t = type(value(a).type); in.type = t.code == 12 ? virtualType(12, {t.ops[0], boolean}) : boolean; trailing(1, 2); break; }
                case 29: { unsigned a = take(); take(); take(); in.type = value(a).type; trailing(0, 1); break; }
                case 34: {
                    require(o.size() >= 3, "call shape"); unsigned flags = unsigned(o[1]); at = 2;
                    if (flags & (1u << 17)) { require(at < o.size(), "call flags"); ++at; }
                    unsigned ft = UINT32_MAX; if (flags & (1u << 15)) { require(at < o.size(), "call explicit type"); ft = unsigned(o[at++]); }
                    unsigned callee = take(); if (ft == UINT32_MAX) ft = subtype(value(callee).type);
                    auto t = type(ft); require(t.code == 21 && t.ops.size() >= 2 && t.ops[0] == 0, "call function type");
                    for (size_t j = 2; j < t.ops.size(); ++j) take(); in.type = unsigned(t.ops[1]); break;
                }
                case 43: {
                    require(o.size() >= 3 && o[0] <= 1, "GEP shape"); unsigned element = unsigned(o[1]); type(element); at = 2;
                    unsigned base = take(); int space = addressSpace(value(base).type); require(space >= 0, "GEP pointer");
                    bool first = true;
                    while (at < o.size()) { unsigned idx = take(); if (!first) { auto t = type(element); uint64_t sub = (t.code == 18 || t.code == 20) ? uint64_t(number(idx)) : 0; element = subtype(element, sub); } first = false; }
                    in.type = pointer(element, unsigned(space)); break;
                }
                case 44: { take(); take(); trailing(2, 2); break; }
                default: throw std::runtime_error("unsupported function opcode");
            }
            finish();
            if (in.type != voidType) { in.result = unsigned(values.size()); add({in.type, false, 0, int(instructions.size())}); }
            instructions.push_back(std::move(in));
        }
        for (auto &in : instructions) for (auto ref : in.refs) value(ref);
    }
    const Instruction *definition(unsigned id) const { int i = value(id).instruction; return i < 0 ? nullptr : &instructions.at(size_t(i)); }
    std::pair<unsigned, int64_t> address(unsigned id, unsigned depth = 0) const {
        require(depth < 32 && addressSpace(value(id).type) == 2, "constant address path");
        const Instruction *in = definition(id);
        if (in && in->record->code == 3 && in->record->operands.back() == 11 && in->refs.size() == 1) return address(in->refs[0], depth + 1);
        if (in && in->record->code == 43 && in->refs.size() == 2 && integerType(unsigned(in->record->operands[1]), 8)) {
            auto base = address(in->refs[0], depth + 1); int64_t offset = number(in->refs[1]);
            require(offset >= 0 && offset <= 1024*1024 && base.second <= 1024*1024 - offset, "constant offset bounds"); base.second += offset; return base;
        }
        return {id, 0};
    }
    Node *proveAndRewrite() {
        unsigned array = UINT32_MAX; size_t arrays = 0;
        for (auto &in : instructions) if (in.record->code == 19 && subtype(in.type) == arrayType) {
            ++arrays; array = in.result;
            require(in.record->operands[3] == 67 && number(in.refs[0]) == 1, "curve alloca flags/count");
        }
        require(arrays == 1, "curve alloca count");
        std::map<unsigned, unsigned> slots{{array, 0}}; Instruction *lookup = nullptr;
        for (auto &in : instructions) if (in.record->code == 43 && !in.refs.empty() && in.refs[0] == array) {
            require(in.record->operands[0] == 1 && in.record->operands[1] == arrayType && in.refs.size() == 3 && number(in.refs[1]) == 0, "curve GEP shape");
            auto &index = value(in.refs[2]); require(integerType(index.type, 64), "curve index type");
            if (index.integer) { require(index.number >= 0 && index.number < 33, "curve slot bounds"); slots[in.result] = unsigned(index.number); }
            else { require(!lookup, "multiple dynamic curve lookups"); lookup = &in; }
        }
        require(lookup, "no dynamic curve lookup");
        std::map<unsigned, std::pair<unsigned, int64_t>> sources; std::map<unsigned, unsigned> sourcePointers;
        size_t firstStore = SIZE_MAX, lastStore = 0, lookupReads = 0;
        for (auto &in : instructions) {
            auto slot = in.refs.empty() ? slots.end() : slots.find(in.refs[0]);
            bool init = in.record->code == 44 && slot != slots.end();
            if (init) {
                auto &o = in.record->operands; require(in.refs.size() == 2 && o[o.size()-2] == 3 && o.back() == 0, "curve store flags");
                const Instruction *load = definition(in.refs[1]);
                require(load && load->record->code == 20 && load->type == floatType && load->refs.size() == 1, "curve initializer is not a float load");
                auto &lo = load->record->operands; require(lo[lo.size()-2] == 3 && lo.back() == 0, "curve load flags");
                unsigned source = load->refs[0]; require(addressSpace(value(source).type) == 2 && subtype(value(source).type) == floatType, "curve source pointer");
                require(!sources.count(slot->second), "repeated curve store");
                sources[slot->second] = address(source); sourcePointers[slot->second] = source;
                firstStore = std::min(firstStore, in.order); lastStore = std::max(lastStore, in.order);
            }
            for (size_t i = 0; i < in.refs.size(); ++i) {
                unsigned used = in.refs[i];
                if (slots.count(used)) {
                    bool allowed = (init && i == 0) || (in.record->code == 43 && i == 0 && used == array && (slots.count(in.result) || &in == lookup));
                    require(allowed, "curve storage escapes or has an unexpected use");
                }
                if (used == lookup->result) {
                    require(in.record->code == 20 && i == 0 && in.type == floatType && in.record->operands.back() == 0 && in.record->operands[in.record->operands.size()-2] == 3, "dynamic curve pointer escapes");
                    ++lookupReads;
                }
            }
        }
        require(sources.size() == 33 && lookupReads == 1 && lastStore < lookup->order, "curve coverage/order");
        auto start = sources.at(0);
        for (unsigned i = 0; i < 33; ++i) require(sources.count(i) && sources.at(i) == std::make_pair(start.first, start.second + 4*i), "noncontiguous curve sources");
        for (auto &in : instructions) if (in.order >= firstStore && in.order < lookup->order) require(in.record->code != 10 && in.record->code != 11 && in.record->code != 15, "control flow during curve initialization");
        // The only semantic change: same integer index, original constant float pointer.
        unsigned source = sourcePointers.at(0), index = lookup->refs[2];
        require(source < lookup->current && index < lookup->current, "replacement value order");
        Node *r = lookup->record; r->operands = {1, floatType, lookup->current - source, lookup->current - index}; r->abbreviation = 0; return r;
    }
};
} // namespace finals
