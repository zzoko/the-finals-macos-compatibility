// Bounded reader/writer for the LLVM bitstream encoding used by converted AIR.
// Original implementation; format reference: https://llvm.org/docs/BitCodeFormat.html
#pragma once
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <map>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace finals {
using Words = std::vector<uint64_t>;
using Bytes = std::vector<uint8_t>;
inline void require(bool ok, const char *reason) { if (!ok) throw std::runtime_error(reason); }
constexpr size_t MaxBytes = 1024 * 1024;
constexpr size_t MaxItems = 100000;
struct Encoding { unsigned kind; uint64_t value; }; // 0 literal, 1 fixed, 2 VBR, 3 array, 4 char6, 5 blob
using Abbrev = std::vector<Encoding>;
using Abbrevs = std::vector<std::shared_ptr<Abbrev>>;
using BlockInfo = std::map<unsigned, Abbrevs>;
struct Node {
    enum Kind { Block, Record, Definition } kind;
    unsigned code = 0, width = 0, abbreviation = 0;
    Words operands;
    Bytes blob;
    std::shared_ptr<Abbrev> definition;
    std::vector<std::unique_ptr<Node>> items;
    size_t position = 0;
    explicit Node(Kind k) : kind(k) {}
};
inline constexpr char Char6[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._";

struct Reader {
    const uint8_t *data; size_t size, bit = 32, items = 0, words = 0;
    uint64_t read(unsigned n) {
        require(n <= 64 && bit <= size * 8 && n <= size * 8 - bit, "bitstream bounds");
        uint64_t result = 0; unsigned out = 0;
        while (n) {
            unsigned take = std::min<unsigned>(n, 8 - (bit & 7));
            result |= uint64_t((data[bit / 8] >> (bit & 7)) & ((1u << take) - 1)) << out;
            bit += take; out += take; n -= take;
        }
        return result;
    }
    uint64_t vbr(unsigned n) {
        require(n >= 2 && n <= 32, "VBR width");
        uint64_t result = 0; unsigned shift = 0;
        for (unsigned group = 0; group < 64; ++group) {
            uint64_t value = read(n), payload = value & ((uint64_t(1) << (n - 1)) - 1);
            require(shift < 64 && payload <= (UINT64_MAX >> shift), "VBR overflow");
            result |= payload << shift;
            if (!(value >> (n - 1))) return result;
            shift += n - 1;
        }
        throw std::runtime_error("VBR length");
    }
    void align() { size_t next = (bit + 31) & ~size_t(31); require(next <= size * 8, "alignment bounds"); bit = next; }
    std::shared_ptr<Abbrev> abbreviation() {
        size_t n = vbr(5); require(n && n <= 64, "abbreviation length");
        auto a = std::make_shared<Abbrev>();
        for (size_t i = 0; i < n; ++i) {
            if (read(1)) a->push_back({0, vbr(8)});
            else {
                unsigned kind = unsigned(read(3)); require(kind >= 1 && kind <= 5, "abbreviation kind");
                uint64_t value = (kind <= 2) ? vbr(5) : 0;
                require(kind > 2 || (value <= 64 && (kind != 2 || (value >= 2 && value <= 32))), "abbreviation width");
                a->push_back({kind, value});
            }
        }
        return a;
    }
    uint64_t scalar(Encoding e) {
        switch (e.kind) {
            case 0: return e.value;
            case 1: return read(unsigned(e.value));
            case 2: return vbr(unsigned(e.value));
            case 4: return uint8_t(Char6[read(6)]);
            default: throw std::runtime_error("non-scalar abbreviation");
        }
    }
    void push(Words &values, uint64_t value) {
        require(++words <= 500000 && values.size() < 32768, "operand budget"); values.push_back(value);
    }
    std::unique_ptr<Node> block(unsigned id, unsigned width, size_t end, BlockInfo &info, unsigned depth, bool top = false) {
        require(depth < 32 && width >= 2 && width <= 16 && end <= size * 8, "block limits");
        auto b = std::make_unique<Node>(Node::Block); b->code = id; b->width = width;
        Abbrevs abbreviations = info[id]; unsigned infoID = UINT32_MAX;
        while (bit < end) {
            require(++items <= MaxItems, "item budget");
            size_t position = bit; unsigned aid = unsigned(read(width));
            if (aid == 0) { require(!top, "top-level end marker"); align(); require(bit == end, "block length mismatch"); return b; }
            if (aid == 1) {
                uint64_t subID = vbr(8), subWidth = vbr(4); require(subID <= 255 && subWidth <= 16, "subblock header");
                align(); uint64_t length = read(32); require(bit <= end && length <= (end - bit) / 32, "subblock length");
                auto sub = block(unsigned(subID), unsigned(subWidth), bit + length * 32, info, depth + 1);
                sub->position = position; b->items.push_back(std::move(sub)); continue;
            }
            if (aid == 2) {
                auto node = std::make_unique<Node>(Node::Definition); node->definition = abbreviation();
                if (id == 0) { require(infoID != UINT32_MAX, "BLOCKINFO selector"); info[infoID].push_back(node->definition); }
                else abbreviations.push_back(node->definition);
                require(abbreviations.size() <= 1024, "abbreviation budget"); b->items.push_back(std::move(node)); continue;
            }
            auto rec = std::make_unique<Node>(Node::Record);
            if (aid == 3) {
                uint64_t code = vbr(6), count = vbr(6); require(code <= 65535 && count <= 32768, "record limits"); rec->code = unsigned(code);
                for (size_t i = 0; i < count; ++i) push(rec->operands, vbr(6));
            } else {
                require(aid >= 4 && aid - 4 < abbreviations.size(), "unknown abbreviation");
                rec->abbreviation = aid; Words values; const auto &a = *abbreviations[aid - 4];
                for (size_t i = 0; i < a.size(); ++i) {
                    auto e = a[i];
                    if (e.kind == 3) {
                        require(i + 2 == a.size() && !values.empty(), "array abbreviation shape");
                        uint64_t count = vbr(6); require(count <= 32768, "array budget");
                        e = a[++i]; for (size_t j = 0; j < count; ++j) push(values, scalar(e));
                    } else if (e.kind == 5) {
                        require(i + 1 == a.size() && !values.empty(), "blob abbreviation shape");
                        size_t count = vbr(6); align(); require(bit <= end && count <= (end - bit) / 8, "blob bounds");
                        rec->blob.assign(data + bit / 8, data + bit / 8 + count); bit += count * 8; align();
                    } else push(values, scalar(e));
                }
                require(!values.empty() && values[0] <= 65535, "abbreviated record code");
                rec->code = unsigned(values[0]); rec->operands.assign(values.begin() + 1, values.end());
            }
            if (id == 0 && rec->code == 1) { require(rec->operands.size() == 1 && rec->operands[0] <= 255, "BLOCKINFO id"); infoID = unsigned(rec->operands[0]); }
            require(bit <= end, "record crosses block"); b->items.push_back(std::move(rec));
        }
        require(top && bit == end, "missing block end"); return b;
    }
};

struct Writer {
    Bytes bytes; size_t bit = 0;
    void write(uint64_t value, unsigned n) {
        require(n <= 64 && bit + n <= 2 * MaxBytes * 8, "output bounds");
        if (n < 64) require((value >> n) == 0, "fixed width overflow");
        bytes.resize((bit + n + 7) / 8, 0);
        while (n) { unsigned take = std::min<unsigned>(n, 8 - (bit & 7)); bytes[bit / 8] |= uint8_t(value & ((1u << take) - 1)) << (bit & 7); value >>= take; bit += take; n -= take; }
    }
    void vbr(uint64_t value, unsigned n) {
        require(n >= 2 && n <= 32, "output VBR width"); uint64_t high = uint64_t(1) << (n - 1);
        do { uint64_t part = value & (high - 1); value >>= n - 1; write(part | (value ? high : 0), n); } while (value);
    }
    void align() { while (bit & 31) write(0, 1); }
    void scalar(Encoding e, uint64_t value) {
        if (e.kind == 0) require(value == e.value, "literal mismatch");
        else if (e.kind == 1) write(value, unsigned(e.value));
        else if (e.kind == 2) vbr(value, unsigned(e.value));
        else if (e.kind == 4) { const char *p = value && value < 128 ? strchr(Char6, int(value)) : nullptr; require(p != nullptr, "char6 mismatch"); write(p - Char6, 6); }
        else throw std::runtime_error("output non-scalar");
    }
    void block(Node &b, BlockInfo &info, bool top = false) {
        Abbrevs abbreviations = info[b.code]; unsigned infoID = UINT32_MAX;
        for (auto &item : b.items) {
            Node &n = *item;
            if (n.kind == Node::Block) {
                n.position = bit; write(1, b.width); vbr(n.code, 8); vbr(n.width, 4); align();
                size_t lengthOffset = bit / 8; write(0, 32); size_t start = bit; block(n, info);
                uint32_t length = uint32_t((bit - start) / 32);
                for (unsigned j = 0; j < 4; ++j) bytes[lengthOffset + j] = uint8_t(length >> (8 * j));
            } else if (n.kind == Node::Definition) {
                write(2, b.width); vbr(n.definition->size(), 5);
                for (auto e : *n.definition) { write(e.kind == 0, 1); if (!e.kind) vbr(e.value, 8); else { write(e.kind, 3); if (e.kind <= 2) vbr(e.value, 5); } }
                if (b.code == 0) { require(infoID != UINT32_MAX, "output BLOCKINFO selector"); info[infoID].push_back(n.definition); } else abbreviations.push_back(n.definition);
            } else {
                if (b.code == 0 && n.code == 1) infoID = unsigned(n.operands.at(0));
                if (!n.abbreviation) { require(n.blob.empty(), "unabbreviated blob"); write(3, b.width); vbr(n.code, 6); vbr(n.operands.size(), 6); for (auto value : n.operands) vbr(value, 6); continue; }
                require(n.abbreviation >= 4 && n.abbreviation - 4 < abbreviations.size(), "output abbreviation");
                write(n.abbreviation, b.width); const auto &a = *abbreviations[n.abbreviation - 4];
                Words values{n.code}; values.insert(values.end(), n.operands.begin(), n.operands.end()); size_t at = 0;
                for (size_t j = 0; j < a.size(); ++j) {
                    auto e = a[j];
                    if (e.kind == 3) { vbr(values.size() - at, 6); e = a.at(++j); while (at < values.size()) scalar(e, values[at++]); }
                    else if (e.kind == 5) { vbr(n.blob.size(), 6); align(); for (auto v : n.blob) write(v, 8); align(); }
                    else { require(at < values.size(), "output value underflow"); scalar(e, values[at++]); }
                }
                require(at == values.size(), "output trailing operands");
            }
        }
        if (!top) { write(0, b.width); align(); }
    }
};
inline std::unique_ptr<Node> parse(const uint8_t *data, size_t size) {
    require(size >= 4 && size <= MaxBytes && !(size & 3) && !memcmp(data, "BC\xc0\xde", 4), "AIR header");
    Reader r{data, size}; BlockInfo info; return r.block(255, 2, size * 8, info, 0, true);
}
inline Bytes serialize(Node &root) {
    Writer w; for (uint8_t c : Bytes{'B','C',0xc0,0xde}) w.write(c, 8);
    BlockInfo info; w.block(root, info, true); return w.bytes;
}
inline Node &oneBlock(Node &parent, unsigned code) {
    Node *found = nullptr; for (auto &p : parent.items) if (p->kind == Node::Block && p->code == code) { require(!found, "duplicate block"); found = p.get(); }
    require(found, "missing block"); return *found;
}
inline std::vector<Node *> records(Node &block) { std::vector<Node *> out; for (auto &p : block.items) if (p->kind == Node::Record) out.push_back(p.get()); return out; }
inline Bytes serializeOffsets(Node &root) {
    Node &mod = oneBlock(root, 8), &vst = oneBlock(mod, 14); Node *offset = nullptr;
    std::vector<Node *> functions, entries;
    for (auto &p : mod.items) { if (p->kind == Node::Block && p->code == 12) functions.push_back(p.get()); if (p->kind == Node::Record && p->code == 13) { require(!offset, "duplicate VST offset"); offset = p.get(); } }
    for (auto *r : records(vst)) if (r->code == 3) entries.push_back(r);
    require(offset && offset->operands.size() == 1 && functions.size() == entries.size(), "VST layout");
    for (unsigned round = 0; round < 8; ++round) {
        auto out = serialize(root); bool changed = false;
        auto update = [&](uint64_t &v, uint64_t value) { if (v != value) { v = value; changed = true; } };
        update(offset->operands[0], vst.position / 32);
        for (size_t i = 0; i < entries.size(); ++i) { require(entries[i]->operands.size() == 2, "VST entry"); update(entries[i]->operands[1], functions[i]->position / 32); }
        if (!changed) return out;
    }
    throw std::runtime_error("VST convergence");
}
} // namespace finals
