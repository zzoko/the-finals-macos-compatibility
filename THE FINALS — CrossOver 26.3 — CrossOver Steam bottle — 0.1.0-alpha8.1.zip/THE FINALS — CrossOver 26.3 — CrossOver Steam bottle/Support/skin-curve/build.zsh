#!/bin/zsh
set -eu
root=${0:A:h}
output=${1:?Usage: build.zsh OUTPUT_DIRECTORY}
mkdir -p -- "$output"
for arch in x86_64 arm64; do
  /usr/bin/clang -fobjc-arc -O2 -arch "$arch" -mmacosx-version-min=11.0 -fvisibility=hidden \
    -ffile-prefix-map="$root"=. -fdebug-prefix-map="$root"=. \
    -c "$root/loader.m" -o "$output/loader-$arch.o"
  /usr/bin/clang++ -std=c++17 -O2 -arch "$arch" -mmacosx-version-min=11.0 -fvisibility=hidden \
    -ffile-prefix-map="$root"=. -fdebug-prefix-map="$root"=. -Wno-deprecated-declarations \
    -c "$root/structural.cpp" -o "$output/structural-$arch.o"
  /usr/bin/clang++ -dynamiclib -arch "$arch" -mmacosx-version-min=11.0 \
    -Wl,-install_name,@rpath/finals-skin-curve.dylib -framework Foundation -framework Metal \
    "$output/loader-$arch.o" "$output/structural-$arch.o" -o "$output/component-$arch.dylib"
done
/usr/bin/lipo -create "$output/component-x86_64.dylib" "$output/component-arm64.dylib" -output "$output/finals-skin-curve.dylib"
/usr/bin/codesign --force --sign - "$output/finals-skin-curve.dylib"
for arch in x86_64 arm64; do
  /usr/bin/lipo "$output/finals-skin-curve.dylib" -verify_arch "$arch"
done
