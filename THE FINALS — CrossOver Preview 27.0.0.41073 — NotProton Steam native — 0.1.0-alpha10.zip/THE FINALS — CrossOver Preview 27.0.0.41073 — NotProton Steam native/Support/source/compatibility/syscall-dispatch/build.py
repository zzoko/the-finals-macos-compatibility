#!/usr/bin/env python3
"""Rebuild the THE FINALS CPU additions from the adjacent checked source patch."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    base = here.parent / 'cpu'
    profile = json.loads((here / 'source-profile.json').read_text())
    for relative, expected in profile['base_files'].items():
        path = base / relative
        if not path.is_file() or path.is_symlink() or digest(path) != expected:
            raise ValueError('CPU source differs from the expected base: ' + relative)
    patch = here / 'cpu.patch'
    if digest(patch) != profile['patch_sha256']:
        raise ValueError('CPU source patch checksum mismatch')
    output = args.output_dir.expanduser().resolve()
    if output.exists():
        raise ValueError('Choose a new output directory; existing outputs are preserved')
    output.mkdir(parents=True)
    source = output / 'source'
    shutil.copytree(base, source)
    with patch.open('rb') as stream:
        subprocess.run(['/usr/bin/patch', '-p1', '--batch', '--forward'],
                       cwd=source, stdin=stream, check=True)
    for relative, expected in profile['changed_files'].items():
        if digest(source / relative) != expected:
            raise ValueError('Patched CPU source checksum mismatch: ' + relative)
    build = output / 'build'
    subprocess.run(['cmake', '-S', str(source), '-B', str(build),
                    '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_OSX_ARCHITECTURES=arm64'], check=True)
    subprocess.run(['cmake', '--build', str(build), '--target',
                    'runtime_loader', 'libRuntimeRosettax87', '-j4'], check=True)
    outputs = {name: digest(build / 'bin' / name)
               for name in ('runtime_loader', 'libRuntimeRosettax87')}
    (output / 'output-sha256.json').write_text(json.dumps(outputs, indent=2) + '\n')
    print('Built private CPU outputs:', build / 'bin')
    print('No installed runtime or game files were changed.')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, subprocess.CalledProcessError) as error:
        sys.exit(str(error))
