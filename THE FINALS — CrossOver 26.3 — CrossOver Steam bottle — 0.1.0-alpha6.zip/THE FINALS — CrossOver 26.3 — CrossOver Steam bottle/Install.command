#!/bin/zsh
emulate -LR zsh
setopt ERR_EXIT NO_UNSET PIPE_FAIL
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
umask 077
base=${0:A:h}; support="$base/Support"
profile=bottle; build=26.3.0.39832; short=26.3
root="$HOME/Library/Application Support/THE FINALS Compatibility"
version=$(<"$support/version.txt")
dest="$root/$short-$version-$profile"
fail() { print -u2 -r -- "Error: $*"; exit 1; }
finish() { local code=$?; if [[ -t 0 ]]; then read -r 'reply?Press Return to close. ' || true; fi; return $code; }
trap finish EXIT
read_path() {
 local input
 read -r "input?$1"
 REPLY=${(Q)input}
 [[ -n $REPLY ]] || fail 'No path entered.'
 [[ $REPLY != '~/'* ]] || REPLY="$HOME/${REPLY#\~/}"
 REPLY=${REPLY:a}
}
print -r -- 'THE FINALS — CrossOver 26.3 — CrossOver Steam bottle'
print -r -- "$version · Apple Silicon · macOS 27 · automatic compatibility check

1  Install / update
2  Verify
3  Restore previous launcher
4  Remove launcher (preserve game and runtime)
5  Clear D3DMetal shader cache (if the game freezes after long play)
0  Exit"
read -r 'choice?Select: '
case $choice in
 0) exit 0 ;;
 1)
  typeset -a args=(--profile "$profile" --destination "$dest")
  if [[ $profile == bottle ]]; then
   typeset -a apps=() bottles=()
   for p in /Applications/*.app(N/) "$HOME"/Applications/*.app(N/); do
    [[ -f $p/Contents/Info.plist ]] || continue
    v=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$p/Contents/Info.plist" 2>/dev/null) || continue
    [[ $v != $build ]] || apps+=("$p")
   done
   if (( ${#apps} == 1 )); then app=$apps[1]
   else read_path "Drag CrossOver $build.app here: "; app=$REPLY; fi
   args+=(--crossover "$app")
   for p in "$HOME/Library/Application Support/CrossOver/Bottles"/*(N/); do
    [[ ! -f "$p/drive_c/Program Files (x86)/Steam/Steam.exe" ]] || bottles+=("$p")
   done
   for ((i=1;i<=${#bottles};i++)); do print -r -- "$i  ${bottles[i]:t}"; done
   print -r -- '0  Choose another bottle folder'
   read -r 'pick?Bottle number: '
   [[ $pick == <-> ]] || fail 'Enter a listed number.'
   if [[ $pick == 0 ]]; then read_path 'Bottle folder: '; bottle=$REPLY
   elif ((pick>=1 && pick<=${#bottles})); then bottle=$bottles[pick]
   else fail 'Unknown bottle number.'; fi
  else
   if /usr/bin/pgrep -x steam_osx >/dev/null || /usr/bin/pgrep -x Steam >/dev/null; then fail 'Quit native Steam before installing this launch integration.'; fi
   source_runtime="$HOME/Library/Application Support/notproton/runners/crossover-$build/CrossOver"
   [[ -d $source_runtime ]] || { read_path "NotProton-prepared CrossOver $build runtime: "; source_runtime=$REPLY; }
   args+=(--source-runtime "$source_runtime")
  fi
  /bin/zsh "$support/install.zsh" --check "${args[@]}"
  if [[ $(/usr/sbin/DevToolsSecurity -status 2>&1) != *enabled* ]]; then
   print -r -- 'The private runtime needs macOS Developer Tools authorization for its startup setup.
This is a system authorization setting; it does not require installing Xcode.
macOS will ask for an administrator password. No game is being launched.'
   read -r 'allow?Enable this authorization now? [y/N]: '
   [[ ${allow:l} == y || ${allow:l} == yes ]] || fail 'Setup cancelled; authorization was not changed.'
   /usr/bin/osascript -e 'do shell script "/usr/sbin/DevToolsSecurity -enable" with administrator privileges' || fail 'Administrator authorization was cancelled or failed.'
   [[ $(/usr/sbin/DevToolsSecurity -status 2>&1) == *enabled* ]] || fail 'macOS has not enabled the required authorization.'
  fi
  /bin/zsh "$support/install.zsh" --install "${args[@]}"
  /bin/zsh "$support/install.zsh" --verify --destination "$dest"
  if [[ $profile == bottle ]]; then
   /bin/zsh "$support/lib/bottle.zsh" --runtime "$dest/CrossOver" --bottle "$bottle"
   print -r -- "Ready: reopen the matching CrossOver app, select ${bottle:t}, and double-click THE FINALS (Patched).
Graphics settings stay in the CrossOver bottle panel. Close other apps in that bottle before switching runtimes."
  else
   /bin/zsh "$support/lib/notproton.zsh" --runtime "$dest/CrossOver"
   print -r -- 'Restart native Steam. For THE FINALS, select the tool matching this download under Properties → Compatibility. Set Graphics to D3DMetal; enable DLSS and High Resolution in that panel if desired. Keep MSync and Advertise AVX2 off for the tested configuration.'
  fi ;;
 2)
  /bin/zsh "$support/install.zsh" --verify --destination "$dest"
  /bin/zsh "$support/lib/$profile.zsh" --verify ;;
 3|4)
  [[ $choice == 3 ]] && mode=--rollback || mode=--remove
  /bin/zsh "$support/lib/$profile.zsh" "$mode" ;;
 5)
  cache_dir="$(/usr/bin/getconf DARWIN_USER_CACHE_DIR)d3dm/Discovery.exe"
  if /usr/bin/pgrep -if 'Discovery.exe' >/dev/null; then fail 'Quit THE FINALS first, then clear the shader cache.'; fi
  if [[ -d $cache_dir ]]; then /bin/rm -rf -- "$cache_dir"; print -r -- 'Shader cache cleared. It rebuilds automatically; expect some stutter for the first session or two.'
  else print -r -- 'No shader cache found; nothing to clear.'; fi ;;
 *) fail 'Choose a listed option.' ;;
esac
