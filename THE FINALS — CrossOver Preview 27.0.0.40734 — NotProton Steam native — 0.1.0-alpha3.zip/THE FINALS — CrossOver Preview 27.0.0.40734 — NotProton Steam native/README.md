# THE FINALS — CrossOver Preview 27.0.0.40734 — NotProton Steam native

Version 0.1.0-alpha3. Private experimental distribution.

Experimental alpha. The byte-identical Preview runtime passed user-confirmed NotProton/native Steam gameplay. A complete online match was separately confirmed with the preceding Windows Steam route; native full-match completion was not separately explicit. See VALIDATION.md.

## Requirements

Apple Silicon, Rosetta, macOS 27.x, your own CrossOver 27.0.0.40734, native macOS Steam and NotProton. This exact older Preview uses GPTK4; a newer Preview is a different input. The installer checks actual runtime hashes, Rosetta signatures and CPU behavior, without requiring one exact macOS build.

Set up the matching CrossOver runner in NotProton first. NotProton 1.2.0 is required: its generic Rosetta launch script is checked by exact file hash. Older NotProton versions are not supported. The script may come from a NotProton runner for another CrossOver build, because the runtime and generated build marker are checked separately. NotProton's Steam bridge must be set up (the installer checks it). No Windows Steam client or CrossOver-managed bottle is required. Install THE FINALS in native Steam, or let Steam recognize an existing library.

## Setup

1. Extract this ZIP completely. Quit native Steam.
2. Open `Install.command` and choose **1 Install / update**. The installer creates a private runtime and performs isolated CPU tests. If needed, it explains and requests macOS Developer Tools startup authorization.
3. Restart Steam. In THE FINALS → Properties → Compatibility, select **THE FINALS - CrossOver Preview 27.0.0.40734 — NotProton Steam native**.
4. Use normal NotProton controls: D3DMetal, MSync off, Advertise AVX2 off. Enable DLSS and High Resolution there if wanted, then choose resolution/upscaling in the game. These controls are passed through. Frame generation is unvalidated.
5. Press Play. English is used only when no explicit `-culture=` or `-language=` argument is supplied.

The private game prefix is `~/Library/Application Support/THE FINALS Compatibility/SteamData-Preview-27.0.0.40734/pfx`. Game storage comes from Steam and may contain spaces. Existing game files, the installed CrossOver app, other tools and the personal Preview setup are preserved.

## Verify and restore

Open `Install.command`: **2** verifies runtime and launcher, **3** restores the previous owned launcher state, **4** removes this launcher while keeping the runtime and game data. Quit Steam before changes. After removing a tool, select your previous tool in Steam's Compatibility panel; the installer never edits Steam's saved per-game choice. First-install restore returns to no package launcher. Keep this ZIP for matching verification.

Source, dependency manifests, licenses and rebuild instructions are under `Support`. Runtime patches reconstruct files from your own exact local inputs; this download contains no full CrossOver, Apple runtime, Steam, NotProton runtime or game. No game/protection binaries or check results are altered. `SHA256SUMS.txt` covers the package files.

Different game/OS/runtime builds and a second Mac remain untested. A passing installer or CPU probe does not establish online gameplay. Nothing has been published.
