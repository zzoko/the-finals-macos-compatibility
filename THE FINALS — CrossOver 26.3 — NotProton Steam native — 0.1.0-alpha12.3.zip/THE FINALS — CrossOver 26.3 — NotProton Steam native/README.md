# THE FINALS — CrossOver 26.3 — NotProton Steam native

Version 0.1.0-alpha12.3. Experimental compatibility package.

The S12 skin correction recognizes the affected curve structurally, without relying on a GPU-family shader-hash allowlist.

## Requirements

Apple Silicon, Rosetta, macOS 27.x, your own CrossOver 26.3.0.39832, native macOS Steam and NotProton. Stable uses GPTK3. The installer checks actual runtime hashes, Rosetta signatures and CPU behavior, without requiring one exact macOS build.

**macOS 27.2 or later (including 27.2.1) is required to use the improved Wine performance optimization; macOS 27.x is sufficient for installation.**

Set up the matching CrossOver runner in NotProton first. NotProton 1.2.5 is required: its generic Rosetta launch script is checked by exact file hash. Other NotProton versions are not supported. The script may come from a NotProton runner for another CrossOver build, because the runtime and generated build marker are checked separately. NotProton's Steam bridge must be set up (the installer checks it). No Windows Steam client or CrossOver-managed bottle is required. Install THE FINALS in native Steam, or let Steam recognize an existing library.

## Setup

1. Extract this ZIP completely. Quit native Steam.
2. Open `Install.command` and choose **1 Install / update**. The installer creates a private runtime and performs isolated CPU tests. If needed, it explains and requests macOS Developer Tools startup authorization.
3. Restart Steam. In THE FINALS → Properties → Compatibility, select **THE FINALS - CrossOver 26.3**.
4. Use normal NotProton controls for Graphics, MSync, Advertise AVX2, DLSS and High Resolution, then choose resolution/upscaling in the game. Explicit launch options override saved NotProton settings; fallback defaults apply only when neither supplies a choice.
5. Press Play. English is used only when no explicit `-culture=` or `-language=` argument is supplied.

The private game prefix is `~/Library/Application Support/THE FINALS Compatibility/SteamData-26.3/pfx`. Game storage comes from Steam and may contain spaces. Existing game files, the installed CrossOver app, other tools and the personal Preview setup are preserved.

## Verify and restore

Open `Install.command`: **2** verifies runtime and launcher, **3** restores the previous owned launcher state, **4** removes this launcher while keeping the runtime and game data, **5** clears the D3DMetal shader cache if the game freezes after long play (it rebuilds automatically). Quit Steam before changes. After removing a tool, select your previous tool in Steam's Compatibility panel; the installer never edits Steam's saved per-game choice. First-install restore returns to no package launcher. Keep this ZIP for matching verification.

Source, dependency manifests, licenses and rebuild instructions are under `Support`. Runtime patches reconstruct files from your own exact local inputs; this download contains no full CrossOver, Apple runtime, Steam, NotProton runtime or game. No game/protection binaries or check results are altered. `SHA256SUMS.txt` covers the package files.


## S12 skin correction

Included by the same `Install.command`; no Xcode, Python or compiler is needed.
The prebuilt component recognizes the affected constant-backed curve and corrects
its lookup in memory. It preserves visibility decisions and leaves unrecognized
patterns unchanged. No game shaders are shipped or changed on disk. This module
can be retired independently when an upstream correction is verified.
