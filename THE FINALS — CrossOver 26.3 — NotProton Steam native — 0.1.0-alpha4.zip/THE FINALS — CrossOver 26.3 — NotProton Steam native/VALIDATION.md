# Validation — 23 October 2026

Route: **THE FINALS — CrossOver 26.3 — NotProton Steam native**, version **0.1.0-alpha4**.
Host: M5 MacBook Air, macOS 27.0.1 (26A434).

## Current result

Installer, CPU checks and isolated launcher checks passed. The final integrated package reached Practice Range with the skin correction active; Stable online play remains unvalidated.

## Package checks

- Exact source/dependency checks, installation into a private runtime and complete runtime-receipt verification passed on this Mac.
- Bundled CPU tests passed NT flags, syscalls, exceptions, IRET and child-process checks in an isolated prefix.
- NotProton dry run, installation, verification, identical reinstall, update, rollback, removal and restore-after-removal passed in an isolated tool directory. App-ID, path, argument, graphics and language controls passed; unrelated registry rows were preserved.
- All generated shell scripts passed macOS zsh syntax checks. Component activation preserves the existing CPU/overlay environment; disabled, changed-payload and unexpected-path controls passed.
- The component passed standalone library loading on both architectures for 28 exact shader variants (14 Preview and 14 Stable), 196 rendering cases and fail-safe controls. Unknown inputs and rejected corrections retain the original library. Standalone checks do not establish online gameplay.

The user confirmed menu skin and first-person hands during the preceding integrated Stable test. The final 28-variant package then relaunched into Practice Range and applied the corrections. No complete Stable online match has been tested.

## Earlier gameplay evidence

On 16 October, the earlier Stable NotProton package reached the authenticated lobby, passed a user Practice Range check and relaunched. The user explicitly did not test a full online match on Stable. Those results predate S12 and do not establish skin correction coverage.

Results apply only to their stated route and implementation. A second Mac, future game/runtime builds, frame generation and other graphics backends remain unvalidated. Installer or standalone success does not establish online gameplay reliability.
