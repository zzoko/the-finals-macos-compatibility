#!/bin/zsh
set -eu
# Developer rebuild only. Install.command uses the included binary; no compiler required.
root=${0:A:h}
output=${1:?Usage: build.zsh OUTPUT_DIRECTORY}
mkdir -p -- "$output"
/usr/bin/clang -dynamiclib -fobjc-arc -O2 -arch x86_64 -arch arm64 \
  -mmacosx-version-min=11.0 -fvisibility=hidden \
  -ffile-prefix-map="$root"=. -fdebug-prefix-map="$root"=. \
  -Wl,-install_name,@rpath/finals-skin-curve.dylib \
  -framework Foundation -framework Metal \
  "$root/loader.m" -o "$output/finals-skin-curve.dylib"
/usr/bin/codesign --force --sign - "$output/finals-skin-curve.dylib"
for required_arch in x86_64 arm64; do
  /usr/bin/lipo "$output/finals-skin-curve.dylib" -verify_arch "$required_arch"
done
