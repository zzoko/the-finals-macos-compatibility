// This project's exact-input reconstruction format. No vendor shader is stored here.
#ifndef FINALS_SKIN_PATCH_H
#define FINALS_SKIN_PATCH_H
#include <CommonCrypto/CommonDigest.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    uint32_t source_offset, copy_size, delta_offset, delta_size;
} FinalsCurveStep;
typedef struct {
    const char *source_sha256, *result_sha256;
    uint32_t source_size, result_size;
    const FinalsCurveStep *steps;
    size_t step_count;
    const unsigned char *delta;
    size_t delta_size;
} FinalsCurveRecipe;

static void finals_curve_digest(const void *data, size_t size, char out[65]) {
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    static const char hex[] = "0123456789abcdef";
    CC_SHA256(data, (CC_LONG)size, digest);
    for (size_t i = 0; i < sizeof(digest); ++i) {
        out[i * 2] = hex[digest[i] >> 4];
        out[i * 2 + 1] = hex[digest[i] & 15];
    }
    out[64] = 0;
}

// Return owned bytes only when both exact hashes and every range validate.
static unsigned char *finals_curve_reconstruct(const FinalsCurveRecipe *recipe,
                                             const void *source, size_t size) {
    if (!recipe || !source || size != recipe->source_size ||
        !recipe->result_size || recipe->result_size > 1024 * 1024 ||
        !recipe->step_count || recipe->step_count > 256) return NULL;
    char hash[65];
    finals_curve_digest(source, size, hash);
    if (strcmp(hash, recipe->source_sha256)) return NULL;
    unsigned char *output = malloc(recipe->result_size);
    if (!output) return NULL;
    size_t at = 0;
    for (size_t i = 0; i < recipe->step_count; ++i) {
        const FinalsCurveStep *step = &recipe->steps[i];
        if (step->source_offset > size || step->copy_size > size - step->source_offset ||
            step->delta_offset > recipe->delta_size ||
            step->delta_size > recipe->delta_size - step->delta_offset ||
            step->copy_size > recipe->result_size - at) goto invalid;
        memcpy(output + at, (const unsigned char *)source + step->source_offset,
               step->copy_size);
        at += step->copy_size;
        if (step->delta_size > recipe->result_size - at) goto invalid;
        if (step->delta_size) memcpy(output + at, recipe->delta + step->delta_offset,
                                    step->delta_size);
        at += step->delta_size;
    }
    if (at != recipe->result_size) goto invalid;
    finals_curve_digest(output, at, hash);
    if (strcmp(hash, recipe->result_sha256)) goto invalid;
    return output;
invalid:
    free(output);
    return NULL;
}
#endif
