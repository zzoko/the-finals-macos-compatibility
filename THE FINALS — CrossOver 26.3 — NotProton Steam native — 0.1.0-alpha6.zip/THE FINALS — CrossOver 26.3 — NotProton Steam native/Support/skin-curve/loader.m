// THE FINALS S12 skin-curve compatibility correction, exact inputs only.
// Reconstructs this project's validated address-space change in memory.
// Unrecognized libraries and reconstruction/Metal failures use the original input.
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#import <objc/runtime.h>
#include <crt_externs.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <unistd.h>
#include "patch.h"
#include "recipes.h"

typedef id (*FinalsLibraryMethod)(id, SEL, dispatch_data_t, NSError **)
    __attribute__((ns_returns_retained));
static FinalsLibraryMethod original_library;
static pthread_mutex_t log_mutex = PTHREAD_MUTEX_INITIALIZER;
static FILE *log_file;
static unsigned char logged[FINALS_CURVE_RECIPE_COUNT];

static void log_message(const char *format, ...) {
    if (!log_file) return;
    pthread_mutex_lock(&log_mutex);
    va_list args;
    va_start(args, format);
    fprintf(log_file, "pid=%d ", getpid());
    vfprintf(log_file, format, args);
    fputc('\n', log_file);
    fflush(log_file);
    va_end(args);
    pthread_mutex_unlock(&log_mutex);
}

static BOOL discovery_process(void) {
    // Wine passes the Windows executable as an argument, sometimes with backslashes.
    // The first .exe is the Windows process. A Steam bridge can pass Discovery.exe
    // later as a launch argument; it must stay outside this component's scope.
    char **args = *_NSGetArgv();
    for (int i = 0; i < *_NSGetArgc(); ++i) {
        const char *base = args[i];
        for (const char *p = base; *p; ++p) if (*p == '/' || *p == '\\') base = p + 1;
        size_t length = strlen(base);
        if (length >= 4 && !strcasecmp(base + length - 4, ".exe"))
            return !strcasecmp(base, "Discovery.exe");
    }
    return NO;
}

static id corrected_library(id device, SEL selector, dispatch_data_t input,
                            NSError **error) __attribute__((ns_returns_retained));
static id corrected_library(id device, SEL selector, dispatch_data_t input,
                            NSError **error) {
    size_t size = input ? dispatch_data_get_size(input) : 0;
    BOOL possible_size = NO;
    for (size_t i = 0; i < FINALS_CURVE_RECIPE_COUNT; ++i)
        if (size == finals_curve_recipes[i].source_size) possible_size = YES;
    if (!possible_size) return original_library(device, selector, input, error);
    const void *bytes = NULL;
    __attribute__((objc_precise_lifetime)) dispatch_data_t map =
        dispatch_data_create_map(input, &bytes, &size);
    if (!map || !bytes) return original_library(device, selector, input, error);
    char hash[65];
    finals_curve_digest(bytes, size, hash);
    for (size_t i = 0; i < FINALS_CURVE_RECIPE_COUNT; ++i) {
        const FinalsCurveRecipe *recipe = &finals_curve_recipes[i];
        if (size != recipe->source_size || strcmp(hash, recipe->source_sha256)) continue;
        unsigned char *output = finals_curve_reconstruct(recipe, bytes, size);
        if (!output) {
            log_message("RECONSTRUCTION_FAILED original=%s; using original", hash);
            return original_library(device, selector, input, error);
        }
        dispatch_data_t candidate = dispatch_data_create(output, recipe->result_size,
            dispatch_get_global_queue(QOS_CLASS_DEFAULT, 0), DISPATCH_DATA_DESTRUCTOR_FREE);
        if (!candidate) {
            free(output);
            return original_library(device, selector, input, error);
        }
        id result = original_library(device, selector, candidate, error);
        if (!result) {
            log_message("REPLACEMENT_FAILED original=%s; using original", hash);
            if (error) *error = nil;
            result = original_library(device, selector, input, error);
            log_message("FALLBACK_ORIGINAL success=%d", result != nil);
            return result;
        }
        pthread_mutex_lock(&log_mutex);
        BOOL first = !logged[i];
        logged[i] = 1;
        pthread_mutex_unlock(&log_mutex);
        if (first) log_message("REPLACE original=%s result=%s", hash, recipe->result_sha256);
        return result;
    }
    return original_library(device, selector, input, error);
}

__attribute__((constructor)) static void initialize_skin_curve(void) {
    @autoreleasepool {
        const char *enabled = getenv("D3DM_FINALS_SKIN_CURVE");
        if (!enabled || strcmp(enabled, "1") || !discovery_process()) return;
        const char *log = getenv("D3DM_FINALS_SKIN_CURVE_LOG");
        if (log && *log) log_file = fopen(log, "a");
        id<MTLDevice> device = MTLCreateSystemDefaultDevice();
        if (!device) return;
        SEL selector = @selector(newLibraryWithData:error:);
        Class cls = object_getClass(device);
        Method method = NULL;
        while (cls) {
            unsigned count = 0;
            Method *methods = class_copyMethodList(cls, &count);
            for (unsigned i = 0; i < count; ++i)
                if (method_getName(methods[i]) == selector) method = methods[i];
            free(methods);
            if (method) break;
            cls = class_getSuperclass(cls);
        }
        if (!method) return;
        original_library = (FinalsLibraryMethod)method_getImplementation(method);
        method_setImplementation(method, (IMP)corrected_library);
        log_message("READY recipes=%d hook=%s", FINALS_CURVE_RECIPE_COUNT, class_getName(cls));
    }
}
