# Optional S12 skin correction

Included in the main installer. It corrects the tested S12 skin shaders in memory;
game files are unchanged. Unknown shader versions pass through unchanged.

The component is independent of the CPU compatibility fix. The installer can disable
it when a later CrossOver update supplies a native correction.

The included binary is built from this directory's source. `build.zsh OUTPUT_DIRECTORY`
is for developers rebuilding it on macOS with Xcode Command Line Tools; installing the
package does not require a compiler. Recipes contain only this project's byte changes
and offsets into the recipient's original libraries, guarded by exact SHA-256 hashes.
No captured shader libraries or vendor source are included.
