"""Emit BSDIFF40 without an extra/literal stream or embedded donor bytes.
Developer tool: Python standard library only. Inputs remain untouched.
"""
from pathlib import Path
import argparse,bz2,hashlib,json,subprocess
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--identity',action='store_true')
parser.add_argument('--input',type=Path,default=Path.home()/'Library/Application Support/notproton/runners/crossover-26.3.0.39832/CrossOver/lib/wine/x86_64-windows/ntdll.dll')
args=parser.parse_args();source=args.input
a=source.read_bytes();b=a if args.identity else (root/'ntdll-np-wine-compat.dll').read_bytes();sha=lambda x:hashlib.sha256(x).hexdigest()
assert sha(a)=='c0e21a9a5250f0a97c08d3c3e1798566255387213e2553b1e555264fb9ded97e'
assert len(a)==len(b)
if not args.identity:assert sha(b)=='9916fbd9c2b495ecc4ce13183c2b7834e866a542ff7e9c0f874b684f96fb7bc7'
def offtout(value):
 assert 0<=value<2**63
 return value.to_bytes(8,'little')
diff=bytes((y-x)&255 for x,y in zip(a,b));assert sum(x!=0 for x in diff)==(0 if args.identity else 24)
control=offtout(len(a))+offtout(0)+offtout(0)
c=bz2.compress(control);d=bz2.compress(diff);e=bz2.compress(b'')
patch=b'BSDIFF40'+offtout(len(c))+offtout(len(d))+offtout(len(b))+c+d+e
name='ntdll-np-identity' if args.identity else 'ntdll-np-wine-compat';target=root/(name+'.bsdiff');target.write_bytes(patch)
assert bz2.decompress(e)==b'' and bz2.decompress(c)==control
reconstructed=bytes((x+y)&255 for x,y in zip(a,bz2.decompress(d)));assert reconstructed==b
verify=root/(name+'.reconstructed.dll')
subprocess.run(['/usr/bin/bspatch',str(source),str(verify),str(target)],check=True)
assert verify.read_bytes()==b
meta={'patch':str(target),'patch_sha256':sha(patch),'patch_bytes':len(patch),'input_sha256':sha(a),'output_sha256':sha(b),'control': [len(a),0,0], 'diff_nonzero_bytes':sum(x!=0 for x in diff),'extra_uncompressed_bytes':0,'bspatch_roundtrip_verified':True,'source_unchanged':sha(source.read_bytes())==sha(a)}
(root/(name+'-delta.json')).write_text(json.dumps(meta,indent=2));print(json.dumps(meta,indent=2))
