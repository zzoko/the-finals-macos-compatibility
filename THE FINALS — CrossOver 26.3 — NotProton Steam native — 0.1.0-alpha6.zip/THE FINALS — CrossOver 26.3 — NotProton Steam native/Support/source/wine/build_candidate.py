"""Guarded developer build step; standard library only. Never patches the input.
The output retains the locally installed NotProton payload without embedding it
in this script. End-user packaging uses a delta, not this Python script.
"""
from pathlib import Path
import argparse,hashlib,json,struct
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--input',type=Path,default=Path.home()/'Library/Application Support/notproton/runners/crossover-26.3.0.39832/CrossOver/lib/wine/x86_64-windows/ntdll.dll')
parser.add_argument('--vendor',type=Path,default=Path('/Applications/CrossOver.app/Contents/SharedSupport/CrossOver/lib/wine/x86_64-windows/ntdll.dll'))
parser.add_argument('--output',type=Path,default=root/'ntdll-np-wine-compat.dll')
args=parser.parse_args()
assert args.output.resolve() not in (args.input.resolve(),args.vendor.resolve()),'Output must be separate from both inputs'
a=args.vendor.read_bytes();b=args.input.read_bytes();sha=lambda x:hashlib.sha256(x).hexdigest()
assert sha(b)=='c0e21a9a5250f0a97c08d3c3e1798566255387213e2553b1e555264fb9ded97e','Unexpected NotProton input'
assert sha(a)=='6dff64c00793ce92124f1316985c63783f539f26b392975c70f57637458d2387','Unexpected original vendor input'
pe=struct.unpack_from('<I',b,0x3c)[0];assert b[pe:pe+4]==b'PE\0\0'
count=struct.unpack_from('<H',b,pe+6)[0];optional_size=struct.unpack_from('<H',b,pe+20)[0]
sections=[]
for i in range(count):
 off=pe+24+optional_size+40*i;name=b[off:off+8].rstrip(b'\0').decode();vsize,rva,size,raw=struct.unpack_from('<IIII',b,off+8)
 sections.append(dict(name=name,header=off,virtual_size=vsize,rva=rva,size=size,raw=raw))
text=next(s for s in sections if s['name']=='.text');npsec=next(s for s in sections if s['name']=='.npdet')
def offset(rva):
 sec=next(s for s in sections if s['rva']<=rva<s['rva']+s['size'])
 return sec['raw']+rva-sec['rva']
assert text['virtual_size']==0x71eb0 and text['rva']==0x1000
stub_rva=0x72ec0;stub=bytes.fromhex('8b5008 83ca01 895308 8b500c 89530c c3')
hook_rva=0x51e5c;hook=b'\xe8'+struct.pack('<i',stub_rva-(hook_rva+5))+b'\x90'
patches=[('skip macOS CW18756 reservation',offset(0x54589),bytes.fromhex('756d'),bytes.fromhex('eb6d')),
 ('copy process flags before original debug flags',offset(hook_rva),bytes.fromhex('8b500c89530c'),hook),
 ('own leaf stub in previously zero padding',offset(stub_rva),b'\0'*len(stub),stub),
 ('extend executable text virtual size within existing raw padding',text['header']+8,struct.pack('<I',0x71eb0),struct.pack('<I',stub_rva+len(stub)-text['rva']))]
assert stub_rva>=text['rva']+text['virtual_size'] and stub_rva+len(stub)<=text['rva']+text['size']
data=bytearray(b)
for label,off,before,after in patches:
 assert len(before)==len(after) and b[off:off+len(before)]==before,(label,'Unexpected original bytes')
 assert off+len(before)<=len(a),(label,'Outside vendor range')
 assert a[off:off+len(before)]==b[off:off+len(before)],(label,'Overlaps NotProton-modified bytes')
 data[off:off+len(after)]=after
assert len(data)==len(b)
npchanged=[i for i in range(len(b)) if i>=len(a) or a[i]!=b[i]]
assert all(data[i]==b[i] for i in npchanged),'NotProton-owned bytes changed'
start=npsec['raw'];end=start+npsec['size'];assert data[start:end]==b[start:end]
assert sha(data)=='9916fbd9c2b495ecc4ce13183c2b7834e866a542ff7e9c0f874b684f96fb7bc7'
args.output.write_bytes(data)
meta={'source':str(args.input),'output':str(args.output),'input_sha256':sha(b),'output_sha256':sha(data),'vendor_sha256':sha(a),'unchanged_size':len(data),'changed_bytes':sum(x!=y for x,y in zip(b,data)),'np_modified_positions_preserved':len(npchanged),'npdet_sha256_before':sha(b[start:end]),'npdet_sha256_after':sha(data[start:end]),'edits':[{'label':label,'file_offset':off,'before':before.hex(),'after':after.hex()} for label,off,before,after in patches],'source_unchanged':sha(args.input.read_bytes())==sha(b),'vendor_unchanged':sha(args.vendor.read_bytes())==sha(a)}
(root/'candidate.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta,indent=2))
