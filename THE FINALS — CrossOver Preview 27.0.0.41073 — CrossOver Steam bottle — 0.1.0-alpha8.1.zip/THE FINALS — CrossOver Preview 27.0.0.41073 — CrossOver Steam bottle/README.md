# THE FINALS — CrossOver Preview 27.0.0.41073 — CrossOver Steam bottle

Version 0.1.0-alpha8.1. Experimental compatibility package.

The S12 skin correction recognizes the affected curve structurally, without relying on a GPU-family shader-hash allowlist.

## Requirements

Apple Silicon, macOS 27.x, Rosetta, your own CrossOver Preview 20261015 (build 27.0.0.41073; not the `arm64` download), and Windows Steam with THE FINALS installed in a 64-bit CrossOver bottle. Use a bottle created or imported by this matching Preview app. NotProton is not required. The installer checks exact local runtime inputs and Rosetta components, then runs isolated CPU tests. No compiler is required for installation.

## Installer and launcher controls

1. Extract the entire ZIP, keeping Install.command beside Support.
2. Close Windows applications in the selected bottle.
3. Open **Install.command**, choose **1 Install / update**, then select the matching CrossOver app and Steam bottle. Existing Steam bottles are listed; another folder can be supplied.
4. Reopen CrossOver, select the bottle and double-click **THE FINALS (Patched)**. The icon is configured to start Windows Steam and THE FINALS through the private runtime. The ordinary Steam icon retains the original runtime.
5. Use normal bottle graphics controls. Select D3DMetal; keep MSync off. Enable DLSS/MetalFX and High Resolution there if wanted, then choose corresponding video settings in the game. Let initial shader compilation finish.

The runtime is installed under `~/Library/Application Support/THE FINALS Compatibility/`. The selected bottle supplies Steam, account state and game files. The installer adds only its owned game icon; it preserves the installed CrossOver app, other launchers, artwork and bottle graphics settings. English is supplied as `-culture=en`.

If needed, the installer explains Developer Tools startup authorization and asks before showing macOS's administrator prompt. Compatibility reports are written under `~/Library/Logs/THE FINALS Compatibility`.

## Shader-cache recovery

If startup reports an RTPSO/pipeline error or recurring graphics freezes occur, quit the game and try **5 — Clear D3DMetal shader cache**, then relaunch. Shaders rebuild.

## Known limitation

This experimental bottle route may fail before Windows Steam opens.

## Manage

Open Install.command: **2** verifies this package's runtime and launcher, **3** restores a previous owned launcher after an update, and **4** removes the launcher while retaining game, bottle and runtime data. On the first installation, use Remove when no previous launcher exists. Quit applications in that bottle before switching runtimes. Keep the matching ZIP for verification. **5** clears the D3DMetal shader cache if the game freezes after long play (it rebuilds automatically).

## Contents

Support contains guarded patches, automatic checks, corresponding source, licenses and rebuild instructions. The package reconstructs a private runtime from your own licensed installation; it contains no complete CrossOver, Apple runtime, Steam, NotProton, game or account data. Game and protection binaries are unchanged. SHA256SUMS.txt covers all packaged files. 

## S12 skin correction

Included by the same `Install.command`; no Xcode, Python or compiler is needed.
The prebuilt component recognizes the affected constant-backed curve and corrects
its lookup in memory. It preserves visibility decisions and leaves unrecognized
patterns unchanged. No game shaders are shipped or changed on disk. This module
can be retired independently when an upstream correction is verified.
