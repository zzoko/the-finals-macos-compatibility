enable_language(ASM)
add_executable(libRuntimeRosettax87 payload.cpp payload.s)
target_compile_options(libRuntimeRosettax87 PRIVATE -O2 -fno-stack-protector
    -fno-exceptions -fno-rtti -fno-unwind-tables -fno-asynchronous-unwind-tables)
target_link_options(libRuntimeRosettax87 PRIVATE -Wl,-no_compact_unwind -static
    -nostdlib -Wl,-pagezero_size,0x0 -Wl,-headerpad,0 -Wl,-e,_start
    -Wl,-segalign,4000 -Wl,-fixup_chains_section)
