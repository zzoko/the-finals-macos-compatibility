/* Original leaf stub implementing the Wine env.c process-parameter fix.
 * At the replaced copy site: RAX = original params, RBX = new params.
 * RDX is scratch and must finish with the original DebugFlags value.
 * No stack allocation, external call, relocation, or NotProton code is needed.
 */
.text
.globl arc_copy_process_flags
arc_copy_process_flags:
    movl 8(%rax), %edx
    orl $1, %edx
    movl %edx, 8(%rbx)
    movl 12(%rax), %edx
    movl %edx, 12(%rbx)
    ret
