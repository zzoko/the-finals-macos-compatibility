# Validation — 16 October 2026

Route: **THE FINALS — CrossOver 26.3 — NotProton Steam native**. Test host: M5 MacBook Air, macOS 27.0.1 (26A434). Game build 25576501; Validation below used NotProton 1.1.8; see the alpha3 note.

## Gameplay

Fresh package installation reached the authenticated lobby. The user confirmed that Practice Range worked well and explicitly clarified that no stable online match was tested.

A clean relaunch reached the authenticated lobby after all previous launcher processes had exited. An earlier rapid restart following forced prefix termination failed with MachExc: PT_THUPDATE failed: Invalid argument, while old/new launcher cleanup overlapped. The overlap is a suspected cause, not a proven diagnosis.

## Installer and standalone checks

- Exact input/dependency checks, actual private-runtime installation and complete runtime receipt verification passed for this route.
- Bundled preflight passed NT flags, syscalls, exceptions, IRET and child-process checks in an isolated prefix.
- All nine memory/TLS/CPU groups and process-scope controls passed on the byte-identical runtime in the preceding validation.
- Runtime payloads and NotProton launch delta are byte-identical to the earlier tested package.
- Adapter dry run, install, verification, identical reinstall, update, rollback, removal and restore after removal passed again for this version.
- Unrelated registry rows were preserved. App-ID guards, missing game path, spaces/apostrophes, populated arguments, language override and graphics-option passthrough passed.
- The generated tool uses the owned /run entry and finals-flavor marker. It requires no traditional CrossOver Steam bottle.
- Wrong build, tampered patch, symbolic-link destination and modified-runtime rejection passed in isolated controls.
- Core runtime verification/removal passed; temporary test runtimes and prefixes were cleaned up.

These results apply only to the stated route. Stable and Preview use different Wine/graphics implementations; bottle and NotProton use different source inputs. A second Mac, fresh native-Steam-only game download, frame generation, other graphics backends and future game/OS/runtime versions remain unvalidated. Installer/probe success does not establish online gameplay reliability.

## alpha3 — NotProton 1.2.0

alpha3 requires NotProton 1.2.0, which replaced the generic run script used by earlier versions. The launcher is now NotProton 1.2.0's script with the same THE FINALS edits applied (runtime path, helper injection, loader and launcher identity). The package patch contains only those edits; the rest comes from your own NotProton 1.2.0. The installer also checks that NotProton's Steam bridge files are present.

The gameplay results above were recorded with the earlier NotProton 1.1.x-based launcher. Runtime payloads, CrossOver inputs and CPU checks are unchanged, but this alpha3 launcher has not yet been launch-tested.
