#!/bin/zsh
# Patch a private copy of the licensed CrossOver 26.3 runtime. Never edit its source.
emulate -LR zsh
setopt ERR_EXIT NO_UNSET PIPE_FAIL
umask 077
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
readonly BUILD=26.3.0.39832
readonly PACKAGE=${0:A:h}
readonly SCRIPT=${0:t}
mode='' source_app=/Applications/CrossOver.app source_runtime='' profile=bottle
destination=''
stage='' install_lock=''
typeset -a inputs=() outputs=() input_hashes=() patches=() patch_hashes=() output_hashes=()
fail() { print -u2 -- "Error: $*"; exit 1; }
[[ -f $PACKAGE/version.txt && ! -L $PACKAGE/version.txt ]] || fail 'Release version file missing.'
readonly VERSION=$(<"$PACKAGE/version.txt")
[[ $VERSION =~ '^[0-9]+\.[0-9]+\.[0-9]+(-[A-Za-z0-9.]+)?$' ]] || fail 'Invalid release version.'
usage() {
  print -r -- "Usage: $SCRIPT MODE [--profile bottle|notproton] [--crossover /path/CrossOver.app]
       [--source-runtime /path/CrossOver] [--destination /path]
  --check       Validate package, exact source build and original hashes; no install.
  --install     Create a private runtime; never replace an existing destination.
  --verify      Verify the existing installation, including every runtime file.
  --uninstall   Verify the owned installation, then move it to your Trash.
  --help        Show this help.
Fixed download profile: bottle. --source-runtime is only valid with --profile notproton.
Default destination: $HOME/Library/Application Support/THE FINALS Compatibility/26.3-VERSION-PROFILE
Requires Apple Silicon, macOS 27.x and compatible Rosetta components (checked automatically).
Only CrossOver $BUILD is accepted. No games are launched or bottles modified."
}
while (( $# )); do
  case $1 in
    --check|--install|--verify|--uninstall)
      [[ -z $mode ]] || fail 'Choose exactly one mode.'; mode=$1; shift ;;
    --crossover|--destination|--profile|--source-runtime)
      (( $# >= 2 )) || fail "Missing value for $1."
      [[ -n $2 && $2 != --* ]] || fail "Missing value for $1."
      case $1 in
        --crossover) source_app=$2 ;; --destination) destination=$2 ;;
        --profile) profile=$2 ;; --source-runtime) source_runtime=$2 ;;
      esac
      shift 2 ;;
    --help|-h) usage; exit 0 ;;
    *) fail "Unknown argument: $1" ;;
  esac
done
[[ -n $mode ]] || { usage; exit 1; }
[[ $profile == bottle ]] || fail 'This download supports only bottle.'
[[ -z $source_runtime || $profile == notproton ]] || fail '--source-runtime is only supported for the notproton profile.'
readonly RELEASE="26.3-$VERSION-$profile"
[[ -n $destination ]] || destination="$HOME/Library/Application Support/THE FINALS Compatibility/$RELEASE"
for value in "$source_app" "$source_runtime" "$destination"; do
  [[ $value != *$'\n'* && $value != *$'\r'* && $value != *$'\t'* ]] || fail 'Paths must not contain tabs or newlines.'
done
source_app=${source_app:a}; destination=${destination:a}
[[ $destination != / && $destination != ${HOME:a} ]] || fail 'Unsafe destination.'
runtime="$source_app/Contents/SharedSupport/CrossOver"
[[ -z $source_runtime ]] || runtime=${source_runtime:a}
[[ $destination != $source_app && $destination != $source_app/* && $source_app != $destination/* ]] || fail 'Source and destination must be separate trees.'
[[ $destination != $runtime && $destination != $runtime/* && $runtime != $destination/* ]] || fail 'Source runtime and destination must be separate trees.'
no_links() {
  local item=$1
  while [[ $item != / ]]; do
    [[ ! -L $item ]] || fail "Refusing symbolic-link path: $item"
    item=${item:h}
  done
}
regular() { no_links "$1"; [[ -f $1 ]] || fail "Required regular file missing: $1"; }
sha() { /usr/bin/shasum -a 256 -- "$1" | /usr/bin/awk '{print $1}'; }
verify_hash() { [[ $(sha "$1") == $2 ]] || fail "SHA-256 mismatch: $1"; }
allowed_path() {
  case $1 in
    lib/arc-nt/libRuntimeRosettax87|lib/arc-nt/runtime_loader|lib/wine/x86_64-unix/ntdll.so|lib/wine/x86_64-unix/wine|lib/wine/x86_64-unix/wine-nt-original|lib/wine/x86_64-windows/ntdll-stock.dll|lib/wine/x86_64-windows/ntdll.dll) return 0 ;;
    *) return 1 ;;
  esac
}
for tool in /usr/bin/bspatch /usr/bin/shasum /usr/sbin/mtree /usr/libexec/PlistBuddy; do
  [[ -x $tool ]] || fail "Required macOS tool missing: $tool"
done
manifest="$PACKAGE/manifest-$profile.tsv"
regular "$manifest"
manifest_hash=$(sha "$manifest")
dependencies="$PACKAGE/dependencies-$profile.tsv"
regular "$dependencies"
dependencies_hash=$(sha "$dependencies")
typeset -a dependency_paths=() dependency_hashes=()
while IFS=$'\t' read -r relative digest extra || [[ -n $relative ]]; do
  [[ -n $relative ]] || continue
  [[ -z $extra && $relative =~ '^[A-Za-z0-9_.-]+(/[A-Za-z0-9_.-]+)+$' && $relative != *'..'* && $digest =~ '^[0-9a-f]{64}$' ]] || fail 'Malformed dependency manifest.'
  dependency_paths+=("$relative"); dependency_hashes+=("$digest")
done < "$dependencies"
(( ${#dependency_paths} > 0 )) || fail 'Empty dependency manifest.'
while IFS=$'\t' read -r input output input_hash patch patch_hash output_hash extra || [[ -n $input ]]; do
  [[ -n $input && $input != \#* ]] || continue
  [[ -z $extra && -n $output_hash ]] || fail 'Manifest must have exactly six tab-separated fields.'
  allowed_path "$input" && allowed_path "$output" || fail 'Manifest contains an unapproved runtime path.'
  [[ $input != */ntdll-stock.dll ]] || fail 'Patch inputs must be original vendor NTDLL files.'
  for digest in "$input_hash" "$patch_hash" "$output_hash"; do
    [[ $digest =~ '^[0-9a-f]{64}$' ]] || fail 'Malformed SHA-256 in manifest.'
  done
  [[ $patch =~ '^(patches/)?[A-Za-z0-9_][A-Za-z0-9_.-]*$' ]] || fail 'Unsafe patch filename.'
  (( ${outputs[(Ie)$output]} == 0 )) || fail "Duplicate output: $output"
  regular "$PACKAGE/$patch"; verify_hash "$PACKAGE/$patch" "$patch_hash"
  inputs+=("$input"); outputs+=("$output"); input_hashes+=("$input_hash")
  patches+=("$patch"); patch_hashes+=("$patch_hash"); output_hashes+=("$output_hash")
done < "$manifest"
(( ${#outputs} == 7 )) || fail 'Unexpected patch output count.'
for required in lib/arc-nt/runtime_loader lib/arc-nt/libRuntimeRosettax87 lib/wine/x86_64-unix/wine lib/wine/x86_64-unix/wine-nt-original lib/wine/x86_64-unix/ntdll.so lib/wine/x86_64-windows/ntdll.dll lib/wine/x86_64-windows/ntdll-stock.dll; do
  (( ${outputs[(Ie)$required]} )) || fail "Missing required output: $required"
done
no_links "$destination"

verify_preflight_files() {
  regular "$PACKAGE/preflight/hostcheck"; verify_hash "$PACKAGE/preflight/hostcheck" b2731559528a72a97a336900b4dd2421897fa5aef44f2486c658e211d97bfeb7
  regular "$PACKAGE/preflight/bounded-run"; verify_hash "$PACKAGE/preflight/bounded-run" 64a1264454a1b7e40ac6884545ac9ccdc862c4a949765b6205b0d8e4787122cf
  regular "$PACKAGE/preflight/cpu-check.zsh"; verify_hash "$PACKAGE/preflight/cpu-check.zsh" 91641f2b26a8270fa2a3e059813691ae354d1fce1e4029a323615f313d4edc20
  regular "$PACKAGE/preflight/ntflag.exe"; verify_hash "$PACKAGE/preflight/ntflag.exe" 2722ae45995cadfe0df05a6850ac9a081b53692a7b15365ae2c76378d2229d00
  regular "$PACKAGE/preflight/ntwincontext.exe"; verify_hash "$PACKAGE/preflight/ntwincontext.exe" 676ccc30036f9209e310fed1374b99b035ea698a2304ef892f50fba352ed739c
  regular "$PACKAGE/preflight/ntchild.exe"; verify_hash "$PACKAGE/preflight/ntchild.exe" c63ca095835843b34293006d002118f93a9f5aa2597655f4413478c066b30713
}
# This game's optional S12 component is independent of the shared CPU correction.
verify_finals_skin_files() {
  regular "$PACKAGE/skin-curve/finals-skin-curve.dylib"
  verify_hash "$PACKAGE/skin-curve/finals-skin-curve.dylib" f192e9d39af470124c8cec1a58d926923e07372d9017b057da83943567f7b7ad
  regular "$PACKAGE/skin-curve/env.zsh"
  verify_hash "$PACKAGE/skin-curve/env.zsh" a315e37ee5933f88a7cbea5eb7b73e95a7615a6ddabf6c80ac46701915e6b5db
  regular "$PACKAGE/skin-curve/loader.m"
  verify_hash "$PACKAGE/skin-curve/loader.m" aa48e5afa3bd6c7927be7a96b5ab54ebba3deb3f6968baba0112cea1a6c8dc8a
  regular "$PACKAGE/skin-curve/patch.h"
  verify_hash "$PACKAGE/skin-curve/patch.h" c56e7688b7eaedf090e08c5a5c6fa79f34787e446761badb521e92366ecfa658
  regular "$PACKAGE/skin-curve/recipes.h"
  verify_hash "$PACKAGE/skin-curve/recipes.h" c42aa81aa6e7ea5d2519c4d9f8d0c9a77f3fbb36b0253326d7677e38cb57b0e2
  regular "$PACKAGE/skin-curve/build.zsh"
  verify_hash "$PACKAGE/skin-curve/build.zsh" ac2535246f16f2aab7a6890663426455cbf61ae9a03561e7fec7bc00d4864e68
  regular "$PACKAGE/skin-curve/README.md"
  verify_hash "$PACKAGE/skin-curve/README.md" 4843d8caa1845eb836c96941d759a5931dcdd2425994d6d5acc8d59749c5de5f
}
verify_host() {
  local os_version=$(/usr/bin/sw_vers -productVersion)
  [[ ${os_version%%.*} == 27 ]] || fail 'This release targets macOS 27.x.'
  verify_preflight_files
  "$PACKAGE/preflight/hostcheck" || fail 'Rosetta components do not match the CPU correction. No launcher was changed.'
  verify_finals_skin_files
}
check_cpu() {
  verify_host
  [[ $(/usr/sbin/DevToolsSecurity -status 2>&1) == *enabled* ]] || fail 'Run Install.command to authorize the required startup setup.'
  /bin/zsh "$PACKAGE/preflight/cpu-check.zsh" "$1" || fail 'CPU behavior check did not pass. See its report.'
}
# The shared CPU check remains mandatory when this game's skin module is retired.
check_finals_compatibility() {
  local checked_runtime=${1:a}
  check_cpu "$checked_runtime"
  verify_finals_skin_files
  local component="$checked_runtime/lib/finals-skin-curve" entry
  no_links "$checked_runtime"
  no_links "$component"
  if [[ -n $stage && $checked_runtime == "$stage/CrossOver" ]]; then
    [[ -d $stage && ! -e $component && ! -L $component ]] || fail 'Skin correction staging directory already exists; nothing replaced.'
    # Explicit failures run the core EXIT cleanup even inside a zsh function.
    /bin/mkdir -m 755 -- "$component" || fail 'Could not create skin correction staging directory.'
    /bin/cp -p -- "$PACKAGE/skin-curve/finals-skin-curve.dylib" "$PACKAGE/skin-curve/env.zsh" "$component/" || fail 'Could not copy the skin correction into staging.'
    /bin/chmod 755 "$component/finals-skin-curve.dylib" || fail 'Could not set skin correction library permissions.'
    /bin/chmod 644 "$component/env.zsh" || fail 'Could not set skin correction environment permissions.'
  elif [[ $checked_runtime != "$destination/CrossOver" ]]; then
    fail 'Skin correction can only be added to this installation staging directory.'
  fi
  # An installed runtime is immutable. Repeat installation verifies it, never repairs it in place.
  no_links "$component"
  [[ -d $component ]] || fail 'Installed skin correction is missing.'
  for entry in "$component"/*(DN); do
    regular "$entry"
    case ${entry:t} in finals-skin-curve.dylib|env.zsh|.DS_Store) ;;
      *) fail 'Unexpected skin correction content; left untouched.' ;;
    esac
  done
  regular "$component/finals-skin-curve.dylib"
  verify_hash "$component/finals-skin-curve.dylib" f192e9d39af470124c8cec1a58d926923e07372d9017b057da83943567f7b7ad
  regular "$component/env.zsh"
  verify_hash "$component/env.zsh" a315e37ee5933f88a7cbea5eb7b73e95a7615a6ddabf6c80ac46701915e6b5db
  print -r -- 'S12 skin correction verified.'
}

verify_source() {
  [[ $(/usr/sbin/sysctl -n hw.optional.arm64 2>/dev/null) == 1 ]] || fail 'This package targets Apple Silicon with Rosetta.'
  /usr/bin/arch -x86_64 /usr/bin/true 2>/dev/null || fail 'Rosetta is required. Install Rosetta before continuing.'
  verify_host
  if [[ $profile == bottle ]]; then
  regular "$source_app/Contents/Info.plist"
  [[ $(/usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$source_app/Contents/Info.plist") == $BUILD ]] || fail "Only CrossOver $BUILD is supported."
  fi
  no_links "$runtime"; [[ -d $runtime ]] || fail "Runtime missing: $runtime"
  local i
  for (( i=1; i<=${#inputs}; ++i )); do
    regular "$runtime/${inputs[i]}"; verify_hash "$runtime/${inputs[i]}" "${input_hashes[i]}"
  done
  for (( i=1; i<=${#dependency_paths}; ++i )); do
    # D3DMetal.framework uses vendor symlinks; accept only links resolving inside this runtime.
    local dependency="$runtime/${dependency_paths[i]}"
    [[ ${dependency:A} == $runtime/* && -f $dependency ]] || fail "Missing or external runtime dependency: $dependency"
    verify_hash "$dependency" "${dependency_hashes[i]}"
  done
}
write_identity() {
  print -r -- "THE FINALS Compatibility installer v1
release=$RELEASE
version=$VERSION
profile=$profile
source_build=$BUILD
manifest_sha256=$manifest_hash
dependencies_sha256=$dependencies_hash"
}
write_receipt() {
  local state_hash=$1 i
  write_identity
  print -r -- "runtime_state_sha256=$state_hash"
  for (( i=1; i<=${#outputs}; ++i )); do
    print -r -- "input=${inputs[i]} sha256=${input_hashes[i]}"
    print -r -- "output=${outputs[i]} sha256=${output_hashes[i]}"
    print -r -- "patch=${patches[i]} sha256=${patch_hashes[i]}"
  done
}
verify_install() {
  no_links "$destination"
  [[ -d $destination ]] || fail "Installation not found: $destination"
  local entry i state_report
  for entry in "$destination"/*(DN); do
    if [[ ${entry:t} == .DS_Store ]]; then regular "$entry"; continue; fi
    case ${entry:t} in CrossOver|.finals-install-marker|receipt.txt|runtime-state.mtree) ;;
      *) fail "Unexpected installation content; refusing changes: $entry" ;;
    esac
  done
  for entry in .finals-install-marker receipt.txt runtime-state.mtree; do regular "$destination/$entry"; done
  [[ $(<"$destination/.finals-install-marker") == $(write_identity) ]] || fail 'Installation ownership/release marker does not match this package.'
  [[ $(<"$destination/receipt.txt") == $(write_receipt "$(sha "$destination/runtime-state.mtree")") ]] || fail 'Installation receipt or runtime-state record was changed.'
  no_links "$destination/CrossOver"; [[ -d $destination/CrossOver ]] || fail 'Installed runtime directory missing.'
  for (( i=1; i<=${#outputs}; ++i )); do
    regular "$destination/CrossOver/${outputs[i]}"
    verify_hash "$destination/CrossOver/${outputs[i]}" "${output_hashes[i]}"
  done
  [[ -z $(/usr/bin/find "$destination/CrossOver" -name .DS_Store ! -type f -print -quit) ]] || fail 'Unexpected Finder metadata type in runtime.'
  state_report=$(/usr/sbin/mtree -X <(print -r -- .DS_Store) -f "$destination/runtime-state.mtree" -p "$destination/CrossOver" 2>&1) || fail "Runtime contents changed; installation was left untouched. $state_report"
  # macOS mtree may report extra entries without a failing exit status.
  [[ -z $state_report ]] || fail "Runtime contents changed; installation was left untouched. $state_report"
}
cleanup() {
  if [[ -n $stage && -d $stage && ! -L $stage ]]; then /bin/rm -rf -- "$stage"; fi
  if [[ -n $install_lock && -d $install_lock && ! -L $install_lock ]]; then /bin/rmdir -- "$install_lock"; fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
case $mode in
  --check)
    verify_source
    [[ ! -e $destination ]] || verify_install
    print -r -- "Validated package and original CrossOver $BUILD. Destination: $destination" ;;
  --verify)
    verify_host
    verify_install
    print -r -- "Verified: $destination/CrossOver" ;;
  --uninstall)
    verify_install
    trash="$HOME/.Trash"; no_links "$trash"
    [[ -d $trash ]] || /bin/mkdir -m 700 -- "$trash"
    trash_slot=$(/usr/bin/mktemp -d "$trash/THE-FINALS-$RELEASE.XXXXXXXX")
    /bin/mv -- "$destination" "$trash_slot/THE FINALS Compatibility" || fail 'Could not move installation to Trash.'
    print -r -- "Moved to Trash: $trash_slot/THE FINALS Compatibility" ;;
  --install)
    verify_source
    if [[ -e $destination ]]; then
      verify_install; check_finals_compatibility "$destination/CrossOver"; print -r -- "Already installed and verified: $destination/CrossOver"; exit 0
    fi
    /bin/mkdir -p -- "${destination:h}"
    no_links "${destination:h}"
    /bin/mkdir -- "$destination.install-lock" || fail 'Another installation is in progress, or its lock needs inspection.'
    install_lock="$destination.install-lock"
    [[ ! -e $destination && ! -L $destination ]] || fail 'Destination appeared before installation began.'
    stage=$(/usr/bin/mktemp -d "${destination:h}/.finals-install.XXXXXXXX")
    print -r -- "Copying original runtime into private staging directory…"
    if ! /bin/cp -cR "$runtime" "$stage/CrossOver"; then
      /bin/rm -rf -- "$stage/CrossOver"
      /usr/bin/ditto "$runtime" "$stage/CrossOver"
    fi
    for (( i=1; i<=${#outputs}; ++i )); do
      target="$stage/CrossOver/${outputs[i]}"
      /bin/mkdir -p "${target:h}"
      no_links "$target"
      # Break copied hard links before replacing this output.
      /bin/rm -f -- "$target"
      /usr/bin/bspatch "$runtime/${inputs[i]}" "$target" "$PACKAGE/${patches[i]}"
      /bin/chmod 755 "$target"
      verify_hash "$target" "${output_hashes[i]}"
    done
    verify_source
    check_finals_compatibility "$stage/CrossOver"
    write_identity > "$stage/.finals-install-marker"
    /usr/sbin/mtree -X <(print -r -- .DS_Store) -c -k type,mode,link,size,sha256digest -p "$stage/CrossOver" > "$stage/runtime-state.mtree"
    write_receipt "$(sha "$stage/runtime-state.mtree")" > "$stage/receipt.txt"
    # -n refuses replacement if another installer creates the destination meanwhile.
    [[ ! -e $destination && ! -L $destination ]] || fail 'Destination appeared during installation.'
    stage_identity=$(/usr/bin/stat -f '%d:%i' "$stage")
    /bin/mv -nh -- "$stage" "$destination"
    [[ ! -d $stage ]] || fail 'Destination was not installed; refusing replacement.'
    [[ $(/usr/bin/stat -f '%d:%i' "$destination") == $stage_identity ]] || fail 'Destination changed concurrently; installation could not be committed at its intended path.'
    stage=''
    print -r -- "Installed: $destination/CrossOver"
    print -r -- "Original CrossOver and existing bottles were not modified." ;;
esac
