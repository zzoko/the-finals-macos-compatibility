# THE FINALS — CrossOver 26.3 — CrossOver Steam bottle

Version 0.1.0-alpha3. Private experimental distribution.

**Launch test failed before Windows Steam started. Gameplay is not validated for this route.**

## Requirements

Apple Silicon, macOS 27.x, Rosetta, your own CrossOver 26.3.0.39832, and Windows Steam with THE FINALS installed in a 64-bit CrossOver bottle.  NotProton is not required. The installer checks exact local runtime inputs and Rosetta components, then runs isolated CPU tests. No compiler is required for installation.

## Installer and launcher controls

1. Extract the entire ZIP, keeping Install.command beside Support.
2. Close Windows applications in the selected bottle.
3. Open **Install.command**, choose **1 Install / update**, then select the matching CrossOver app and Steam bottle. Existing Steam bottles are listed; another folder can be supplied.
4. Reopen CrossOver, select the bottle and double-click **THE FINALS (Patched)**. The icon is configured to start Windows Steam and THE FINALS through the private runtime; the current launch test failed before Steam opened. The ordinary Steam icon retains the original runtime.
5. Use normal bottle graphics controls. D3DMetal is the tested backend; use MSync off for the tested configuration. Enable DLSS/MetalFX and High Resolution there if wanted, then choose corresponding video settings in the game. Let initial shader compilation finish.

The runtime is installed under `~/Library/Application Support/THE FINALS Compatibility/`. The selected bottle supplies Steam, account state and game files. The installer adds only its owned game icon; it preserves the installed CrossOver app, other launchers, artwork and bottle graphics settings. English is supplied as `-culture=en`.

If needed, the installer explains Developer Tools startup authorization and asks before showing macOS's administrator prompt. Compatibility reports are written under `~/Library/Logs/THE FINALS Compatibility`.

## Manage

Open Install.command: **2** verifies this package's runtime and launcher, **3** restores a previous owned launcher after an update, and **4** removes the launcher while retaining game, bottle and runtime data. On the first installation, use Remove when no previous launcher exists. Quit applications in that bottle before switching runtimes. Keep the matching ZIP for verification.

## Validation and contents

Installer, CPU checks and isolated menu lifecycle checks passed. The actual game-launch test crashed before Windows Steam started; this bottle route is not validated for gameplay.

Read **VALIDATION.md** for this exact route's installer, standalone and gameplay status. Results from another route do not certify this package. A second Mac, future game/runtime builds and every graphics setting remain untested.

Support contains guarded patches, automatic checks, corresponding source, licenses and rebuild instructions. The package reconstructs a private runtime from your own licensed installation; it contains no complete CrossOver, Apple runtime, Steam, NotProton, game or account data. Game and protection binaries are unchanged. SHA256SUMS.txt covers all packaged files. Nothing has been published.

## S12 skin correction

Included automatically by the same `Install.command`. It reconstructs the corrected
Metal shader from an exact matching input in memory; no game shader files are shipped
or modified. The correction retains the original visibility decisions. The component
is separate from the CPU fix and can be retired when an upstream fix is verified.
Unknown shader versions keep their original behavior. See `VALIDATION.md` for route-specific coverage.
