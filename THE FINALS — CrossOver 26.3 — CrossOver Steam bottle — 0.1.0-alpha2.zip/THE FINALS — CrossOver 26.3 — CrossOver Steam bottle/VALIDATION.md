# Validation — 16 October 2026

Route: **THE FINALS — CrossOver 26.3 — CrossOver Steam bottle**. Test host: M5 MacBook Air, macOS 27.0.1 (26A434). Game build 25576501; NotProton tests used 1.1.8.

## Gameplay

This stable CrossOver bottle package has not received a separate gameplay trial. Stable NotProton reached Practice Range, but that uses a different PE NTDLL and Steam launch route.

A game relaunch through this newly packaged bottle icon has not been tested.

## Installer and standalone checks

- Exact input/dependency checks, actual private-runtime installation and complete runtime receipt verification passed for this route.
- Bundled preflight passed NT flags, syscalls, exceptions, IRET and child-process checks in an isolated prefix.
- All nine memory/TLS/CPU groups and Discovery opt-in/unrelated-process opt-out controls passed on the reconstructed bottle runtime.
- Actual CrossOver cxmenu registration and menu-start passed in an isolated test bottle, using a harmless marker instead of a game.
- Dry run, install, verification, identical reinstall, update, rollback and removal passed.
- Existing Steam menu entries, artwork and cxbottle.conf were preserved through installation/removal.
- Both enabled and disabled optional graphics values reached the child through the vendor bottle wrapper.
- Paths containing spaces and an apostrophe, cached artwork, Finder metadata and modified-menu/launcher refusal passed.
- No Windows Steam client or game was executed by these adapter checks.
- Wrong build, tampered patch, symbolic-link destination and modified-runtime rejection passed in isolated controls.
- Core runtime verification/removal passed; temporary test runtimes and prefixes were cleaned up.

These results apply only to the stated route. Stable and Preview use different Wine/graphics implementations; bottle and NotProton use different source inputs. A second Mac, fresh native-Steam-only game download, frame generation, other graphics backends and future game/OS/runtime versions remain unvalidated. Installer/probe success does not establish online gameplay reliability.
