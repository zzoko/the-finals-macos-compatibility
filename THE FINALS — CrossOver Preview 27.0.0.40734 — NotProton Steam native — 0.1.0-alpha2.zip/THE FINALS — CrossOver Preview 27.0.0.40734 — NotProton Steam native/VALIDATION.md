# Validation — 16 October 2026

Route: **THE FINALS — CrossOver Preview 27.0.0.40734 — NotProton Steam native**. Test host: M5 MacBook Air, macOS 27.0.1 (26A434). Game build 25576501; NotProton tests used 1.1.8.

## Gameplay

The byte-identical Preview runtime passed user-confirmed NotProton/native Steam gameplay. A complete online match was separately confirmed with the preceding Windows Steam route; native full-match completion was not separately explicit.

The maintained NotProton/native Steam Preview launcher reached the lobby on repeated launches. The package adapter passes isolated checks; a fresh package-created Preview prefix has not separately been played.

## Installer and standalone checks

- Exact input/dependency checks, actual private-runtime installation and complete runtime receipt verification passed for this route.
- Bundled preflight passed NT flags, syscalls, exceptions, IRET and child-process checks in an isolated prefix.
- All nine memory/TLS/CPU groups and process-scope controls passed on the byte-identical runtime in the preceding validation.
- Runtime payloads and NotProton launch delta are byte-identical to the earlier tested package.
- Adapter dry run, install, verification, identical reinstall, update, rollback, removal and restore after removal passed again for this version.
- Unrelated registry rows were preserved. App-ID guards, missing game path, spaces/apostrophes, populated arguments, language override and graphics-option passthrough passed.
- The generated tool uses the owned /run entry and finals-flavor marker. It requires no traditional CrossOver Steam bottle.
- Wrong build, tampered patch, symbolic-link destination and modified-runtime rejection passed in isolated controls.
- Core runtime verification/removal passed; temporary test runtimes and prefixes were cleaned up.

These results apply only to the stated route. Stable and Preview use different Wine/graphics implementations; bottle and NotProton use different source inputs. A second Mac, fresh native-Steam-only game download, frame generation, other graphics backends and future game/OS/runtime versions remain unvalidated. Installer/probe success does not establish online gameplay reliability.
