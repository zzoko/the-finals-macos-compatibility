#!/bin/zsh
# Optional adapter; derive launch scripts only from the user's owned NotProton shim.
emulate -LR zsh
setopt ERR_EXIT NO_UNSET PIPE_FAIL
umask 077
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
readonly tool_id=notproton-finals-preview40734-compat build_id=27.0.0.40734
readonly source_hash=7e187ec91d260dc53fe97299862fa9f16e0f704bc160c352f8edaa7466a67ea2
readonly display_name='THE FINALS - CrossOver Preview 27.0.0.40734 — NotProton Steam native'
readonly marker_text='THE FINALS Compatibility NotProton adapter v2'
readonly state_marker='THE FINALS Compatibility NotProton state v1'
typeset -a tool_files=(finals-run run-base run compatibilitytool.vdf toolmanifest.vdf build finals-flavor)
default_tools="$HOME/Library/Application Support/Steam/compatibilitytools.d"
runtime='' source_tool='' tool_root=$default_tools mode=install
registry="$HOME/Library/Application Support/notproton/tools"
data="$HOME/Library/Application Support/THE FINALS Compatibility/SteamData-Preview-27.0.0.40734"
state_dir="$HOME/Library/Application Support/THE FINALS Compatibility/NotProtonAdapter-Preview-27.0.0.40734-entry2"
integer dry=0 production=0 row_count=0
stage='' registry_temp='' lock_dir='' current_row=''
integer old_moved=0 new_moved=0 registry_moved=0 previous_moved=0 previous_published=0 committed=0
fail() { print -u2 -r -- "Error: $*"; exit 1; }
usage() {
  print -r -- "Usage: notproton.zsh [--runtime PATH | --rollback | --remove | --verify]
  [--source-tool PATH] [--tool-root PATH] [--registry PATH] [--data PATH]
  [--state-dir PATH] [--dry-run]
Default mode installs/updates from a core-verified NotProton-compatible runtime.
--rollback swaps current and previous owned tool/registry state, including undoing removal.
--remove unregisters and archives only this owned tool; runtime and game prefix remain.
--verify checks the active owned tool and registry without writing or requiring Steam to close.
--tool-root is the compatibilitytools.d parent. Backups are outside it in --state-dir.
--dry-run validates the plan without installation writes. Exit 0 means success.
No game or Steam is launched. Native Steam must be closed for production writes."
}
while (( $# )); do
  case $1 in
    --runtime|--source-tool|--tool-root|--registry|--data|--state-dir)
      (( $# >= 2 )) && [[ -n $2 && $2 != --* ]] || fail "Missing value for $1."
      case $1 in
        --runtime) runtime=$2 ;; --source-tool) source_tool=$2 ;; --tool-root) tool_root=$2 ;;
        --registry) registry=$2 ;; --data) data=$2 ;; --state-dir) state_dir=$2 ;;
      esac; shift 2 ;;
    --rollback|--remove|--verify) [[ $mode == install ]] || fail 'Choose one mode.'; mode=${1#--}; shift ;;
    --dry-run) dry=1; shift ;; --help|-h) usage; exit 0 ;;
    *) fail "Unknown argument: $1" ;;
  esac
done
[[ $mode != install || -n $runtime ]] || { usage; exit 1; }
sha() { /usr/bin/shasum -a 256 -- "$1" | /usr/bin/awk '{print $1}'; }
no_links() { local p=$1; while [[ $p != / ]]; do [[ ! -L $p ]] || fail "Symbolic-link path refused: $p"; p=${p:h}; done; }
for value in "$runtime" "$source_tool" "$tool_root" "$registry" "$data" "$state_dir"; do
  [[ $value != *$'\n'* && $value != *$'\r'* && $value != *$'\t'* ]] || fail 'Paths cannot contain tabs or newlines.'
done
tool_root=${tool_root:a}; registry=${registry:a}; data=${data:a}; state_dir=${state_dir:a}
target="$tool_root/$tool_id"; previous="$state_dir/previous"
[[ $tool_root != / && $data != / && $state_dir != / && $state_dir != ${HOME:a} ]] || fail 'Unsafe target path.'
[[ $state_dir != $tool_root && $state_dir != $tool_root/* && $tool_root != $state_dir/* ]] || fail 'State and tool directories must be separate trees.'
for value in "$tool_root" "$registry" "$data" "$state_dir"; do no_links "$value"; done
row="$tool_id"$'\t'"$build_id"$'\t'"rosetta"$'\t'"$display_name"
state_identity="$state_marker"$'\n'"tool=$target"$'\n'"registry=$registry"
files_record() { local f; for f in $tool_files; do print -r -- "$(sha "$1/$f")"$'\t'"$f"; done; }
verify_tool() {
  local p=$1 f
  no_links "$p"
  [[ -d $p && -f $p/.finals-adapter-owner && -f $p/.finals-adapter-files ]] || fail "Unowned tool: $p"
  [[ $(<"$p/.finals-adapter-owner") == $marker_text ]] || fail "Tool ownership mismatch: $p"
  [[ $(/bin/ls -A "$p") == $(print -rl -- .finals-adapter-files .finals-adapter-owner $tool_files | /usr/bin/sort) ]] || fail "Unexpected tool content: $p"
  for f in $tool_files .finals-adapter-owner .finals-adapter-files; do no_links "$p/$f"; [[ -f $p/$f ]] || fail "Missing tool file: $f"; done
  [[ $(<"$p/.finals-adapter-files") == $(files_record "$p") ]] || fail "Owned tool was modified: $p"
  for f in finals-run run-base run; do [[ -x $p/$f ]] || fail "Tool executable permission changed: $f"; done
}
verify_snapshot() {
  local p=$1 f
  no_links "$p"
  for f in present registry-row; do no_links "$p/$f"; [[ -f $p/$f ]] || fail "Invalid previous-state snapshot: $p"; done
  [[ $(<"$p/registry-row") == '' || $(<"$p/registry-row") == $row ]] || fail 'Previous registry row does not belong to this adapter.'
  case $(<"$p/present") in
    1) [[ $(/bin/ls -A "$p") == $'present\nregistry-row\ntool' ]] || fail 'Unexpected snapshot content.'; verify_tool "$p/tool" ;;
    0) [[ $(/bin/ls -A "$p") == $'present\nregistry-row' && $(<"$p/registry-row") == '' ]] || fail 'Invalid absent-state snapshot.' ;;
    *) fail 'Invalid previous-state presence marker.' ;;
  esac
}
if [[ -e $state_dir ]]; then
  [[ -d $state_dir && -f $state_dir/.finals-adapter-state && ! -L $state_dir/.finals-adapter-state ]] || fail 'State directory is not owned by this adapter.'
  [[ $(<"$state_dir/.finals-adapter-state") == $state_identity ]] || fail 'State directory belongs to different target paths.'
  for entry in "$state_dir"/*(DN); do
    case ${entry:t} in .finals-adapter-state|previous) ;; *) fail "Unexpected/interrupted state retained for recovery: $entry" ;; esac
  done
  [[ ! -e $previous ]] || verify_snapshot "$previous"
fi
[[ ! -e $target ]] || verify_tool "$target"
[[ ! -e $registry || -f $registry ]] || fail 'Registry must be a regular file.'
registry_before=absent; [[ ! -f $registry ]] || registry_before=$(sha "$registry")
if [[ -f $registry ]]; then
  while IFS= read -r line || [[ -n $line ]]; do
    [[ ${line%%$'\t'*} == $tool_id ]] || continue
    (( ++row_count )); [[ $line == $row && -d $target ]] || fail 'Registry tool ID is not owned by this configuration.'
    current_row=$line
  done < "$registry"
fi
(( row_count <= 1 )) || fail 'Duplicate tool IDs in registry.'
if [[ $mode == verify ]]; then
  [[ -d $target && -z $current_row ]] || fail 'Owned disk-discovered tool is required; it must not be managed by NotProton regeneration.'
  print -r -- "Verified owned Steam adapter: $target"; exit 0
fi
for value in "$target" "$registry"; do
  case $value in "$HOME/Library/Application Support/Steam"/*|"$HOME/Library/Application Support/notproton"/*) production=1 ;; esac
done
steam_stopped() {
  (( ! production )) || { ! /usr/bin/pgrep -x steam_osx >/dev/null && ! /usr/bin/pgrep -x Steam >/dev/null; } \
    || fail 'Quit native Steam before changing its compatibility tools; no process was stopped.'
}
if [[ $mode == install ]]; then
  runtime=${runtime:a}; no_links "$runtime"
  if [[ -z $source_tool ]]; then
    typeset -a matches=()
    for candidate in "$default_tools"/*(N/); do
      [[ ${candidate:t} != $tool_id && -f $candidate/build && -f $candidate/flavor && -f $candidate/run ]] || continue
      # Ignore this project's derived tools when finding the original NotProton tool.
      [[ ${candidate:t} != *arc* && ${candidate:t} != *finals* ]] || continue
      [[ $(<"$candidate/flavor") == rosetta ]] || continue
      [[ $(sha "$candidate/run") == $source_hash ]] && matches+=("$candidate")
    done
    (( ${#matches} >= 1 )) || fail 'No supported original NotProton shim found; provide --source-tool explicitly.'
    source_tool=$matches[1]
  fi
  source_tool=${source_tool:a}; no_links "$source_tool"
  for file in build flavor run; do no_links "$source_tool/$file"; [[ -f $source_tool/$file ]] || fail "Missing source $file."; done
  [[ $(<"$source_tool/flavor") == rosetta ]] || fail 'A Rosetta NotProton source tool is required.'
  [[ $(sha "$source_tool/run") == $source_hash ]] || fail 'Unsupported NotProton shim hash; nothing changed.'
  for file in bin/wineserver lib/wine/x86_64-unix/wine lib/wine/x86_64-unix/ntdll.so lib/wine/x86_64-windows/ntdll.dll; do
    [[ -f $runtime/$file ]] || fail "Verified runtime is incomplete: $file"
  done
  [[ -x $runtime/bin/wineserver && -x $runtime/lib/wine/x86_64-unix/wine ]] || fail 'Runtime executables are not executable.'
elif [[ $mode == rollback ]]; then
  [[ -d $previous ]] || fail 'No previous adapter state to restore.'
fi
quote_sh() { REPLY=${(qq)1}; }
quote_sh "$runtime"; runtime_quoted=$REPLY
quote_sh "$data"; data_quoted=$REPLY
readonly launcher_patch="${0:A:h:h}/patches/notproton-run.bsdiff"
generate_base() {
  local temp template_text
  [[ $(sha "$launcher_patch") == a9e513034f23396088a16ab37b7acd6edc491f0c1e584dbffd1642ca95522563 ]] || fail 'Launcher patch checksum mismatch.'
  temp=$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/finals-render.XXXXXXXX") || return 1
  {
    /usr/bin/bspatch "$source_tool/run" "$temp/run-base" "$launcher_patch" || return 1
    [[ $(sha "$temp/run-base") == 66bd25e470f0ec1839b266983272a225f24159cf49cad51668471d8e1f83ee63 ]] || fail 'Reconstructed launcher checksum mismatch.'
    template_text=$(<"$temp/run-base")
    [[ $template_text == *__FINALS_RUNTIME_SHELL__* ]] || fail 'Missing runtime path marker.'
    print -r -- "${template_text/__FINALS_RUNTIME_SHELL__/$runtime_quoted}"
  } always {
    /bin/rm -rf -- "$temp"
  }
}
generate_wrapper() {
  print -r -- '#!/bin/zsh
emulate -LR zsh
setopt ERR_EXIT NO_UNSET PIPE_FAIL
arc_id=${STEAM_COMPAT_APP_ID:-${SteamAppId:-}}
[[ $arc_id == 2073850 ]] || { print -u2 -- "This compatibility tool is only for THE FINALS (2073850)."; exit 1; }'
  print -r -- 'for arc_other_id in "${SteamAppId:-}" "${SteamGameId:-}"; do
  [[ -z $arc_other_id || $arc_other_id == 0 || $arc_other_id == 2073850 ]] || {
    print -u2 -- "Conflicting Steam application ID; refusing this launch."; exit 1
  }
done'
  print -r -- "export STEAM_COMPAT_DATA_PATH=$data_quoted"
  print -r -- 'case ${1:-} in
  getcompatpath) print -r -- "$STEAM_COMPAT_DATA_PATH"; exit 0 ;;
esac
[[ -n ${STEAM_COMPAT_INSTALL_PATH:-} && -d $STEAM_COMPAT_INSTALL_PATH ]] || {
  print -u2 -- "Steam did not provide an existing game installation path."; exit 1
}
mkdir -p -- "$STEAM_COMPAT_DATA_PATH"
export ARC_NATIVE_CODE_REGIONS=1 WINEDEBUG=-all
# Optional graphics settings come from the NotProton controls.
export ARC_NT_USE_AOT=1
# English avoids the missing-localization first-run screen in a new prefix.
case ${1:-} in
  run|waitforexitandrun)
    arc_has_language=0
    for arc_arg in "$@"; do
      case ${arc_arg:l} in -culture=*|-language=*) arc_has_language=1 ;; esac
    done
    if (( ! arc_has_language )); then set -- "$@" -culture=en; fi ;;
esac
exec "${0:A:h}/run-base" "$@"'
}
if [[ $mode == install ]]; then generate_base | /bin/sh -n; generate_wrapper | /bin/zsh -n; fi
if (( dry )); then
  print -r -- "Validated $mode plan. Runtime compatibility is verified separately by the core installer.
Tool: $target
Registry: $registry
Rollback state: $previous
Dry run: no files installed or registration changed."
  exit 0
fi
[[ $mode != remove || -d $target ]] || { print -r -- 'Already removed; rollback state preserved.'; exit 0; }
steam_stopped
undo_transaction() {
  if (( previous_published )); then /bin/mv -- "$previous" "$stage/prior" || return 1; fi
  if (( new_moved )); then /bin/mv -- "$target" "$stage/failed-new" || return 1; fi
  if (( old_moved )); then /bin/mv -- "$stage/prior/tool" "$target" || return 1; fi
  if (( registry_moved )); then
    [[ $(sha "$registry") == $registry_after ]] || return 1
    if [[ $registry_before == absent ]]; then /bin/rm -f -- "$registry" || return 1
    else /bin/mv -f -- "$stage/registry-original" "$registry" || return 1; fi
  fi
  if (( previous_moved )); then /bin/mv -- "$stage/old-previous" "$previous" || return 1; fi
  return 0
}
cleanup() {
  local exit_code=$?
  if (( ! committed && (old_moved || new_moved || registry_moved || previous_moved) )); then
    if ! undo_transaction; then
      print -u2 -r -- "Recovery data retained after interrupted transaction: $stage"
      stage=''; exit_code=1
    fi
  fi
  [[ -z $stage || ! -d $stage ]] || /bin/rm -rf -- "$stage"
  [[ -z $registry_temp || ! -f $registry_temp ]] || /bin/rm -f -- "$registry_temp"
  [[ -z $lock_dir || ! -d $lock_dir ]] || /bin/rmdir -- "$lock_dir" 2>/dev/null || true
  return $exit_code
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
/bin/mkdir -p -- "$tool_root" "${registry:h}" "$state_dir"
[[ $(/usr/bin/stat -f '%d' "$tool_root") == $(/usr/bin/stat -f '%d' "$state_dir") ]] || fail 'Tool and rollback state must be on the same filesystem for atomic renames.'
if [[ ! -f $state_dir/.finals-adapter-state ]]; then print -r -- "$state_identity" > "$state_dir/.finals-adapter-state"; fi
lock_dir="$tool_root/.$tool_id.lock"
/bin/mkdir -- "$lock_dir" 2>/dev/null || { lock_dir=''; fail 'Another adapter operation is active.'; }
stage=$(/usr/bin/mktemp -d "$state_dir/.transaction.XXXXXXXX")
/bin/mkdir -- "$stage/prior"
print -r -- "$current_row" > "$stage/prior/registry-row"
if [[ -d $target ]]; then print -r -- 1 > "$stage/prior/present"; else print -r -- 0 > "$stage/prior/present"; fi
[[ ! -f $registry ]] || /bin/cp -p -- "$registry" "$stage/registry-original"
desired_row=''
if [[ $mode == install ]]; then
  /bin/mkdir -- "$stage/next"
  generate_base > "$stage/next/run-base"; generate_wrapper > "$stage/next/finals-run"
  # /run and a notproton-prefixed directory are the NotProton shell-hook interface.
  # Own this entry ourselves: no source-managed registry row or flavor file.
  print -r -- '#!/bin/zsh
# THE FINALS compatibility entry point; managed by the THE FINALS installer.
exec "${0:A:h}/finals-run" "$@"' > "$stage/next/run"
  [[ $(sha "$source_tool/run") == $source_hash ]] || fail 'Source shim changed during staging.'
  print -r -- "$build_id" > "$stage/next/build"; print -r -- rosetta > "$stage/next/finals-flavor"
  print -r -- "$marker_text" > "$stage/next/.finals-adapter-owner"
  print -r -- '"manifest" { "version" "2" "commandline" "/run %verb%" }' > "$stage/next/toolmanifest.vdf"
  print -r -- "\"compatibilitytools\" { \"compat_tools\" { \"$tool_id\" {
  \"install_path\" \".\" \"display_name\" \"$display_name\"
  \"from_oslist\" \"windows\" \"to_oslist\" \"macos\"
} } }" > "$stage/next/compatibilitytool.vdf"
  /bin/chmod +x "$stage/next/run" "$stage/next/run-base" "$stage/next/finals-run"
  files_record "$stage/next" > "$stage/next/.finals-adapter-files"
  desired_row=''  # Steam discovers the VDF; NotProton must not regenerate our run.
elif [[ $mode == rollback ]]; then
  [[ $(<"$previous/present") != 1 ]] || /bin/cp -pR -- "$previous/tool" "$stage/next"
  desired_row=$(<"$previous/registry-row")
fi
[[ ! -d $stage/next ]] || verify_tool "$stage/next"
if [[ -d $target && -d $stage/next && $current_row == $desired_row ]]; then
  if /usr/bin/diff -qr -- "$target" "$stage/next" >/dev/null; then
    print -r -- 'Already installed and identical; previous rollback state preserved.'; exit 0
  fi
elif [[ ! -e $target && ! -d $stage/next && $current_row == $desired_row ]]; then
  print -r -- 'State already matches; previous rollback state preserved.'; exit 0
fi
registry_temp=$(/usr/bin/mktemp "${registry:h}/.finals-registry.XXXXXXXX")
if [[ -f $registry ]]; then
  /bin/cp -p -- "$registry" "$registry_temp"
  /usr/bin/awk -F '\t' -v id="$tool_id" '$1 != id' "$registry" > "$registry_temp"
fi
[[ -z $desired_row ]] || print -r -- "$desired_row" >> "$registry_temp"
registry_after=$(sha "$registry_temp")
steam_stopped
registry_now=absent; [[ ! -f $registry ]] || registry_now=$(sha "$registry")
[[ $registry_now == $registry_before ]] || fail 'Registry changed during staging; nothing committed.'
[[ ! -e $target ]] || verify_tool "$target"
commit_changes() {
  if [[ -d $previous ]]; then /bin/mv -- "$previous" "$stage/old-previous" || return 1; previous_moved=1; fi
  if [[ -d $target ]]; then /bin/mv -- "$target" "$stage/prior/tool" || return 1; old_moved=1; fi
  if [[ -d $stage/next ]]; then
    [[ ! -e $target && ! -L $target ]] || return 1
    /bin/mv -- "$stage/next" "$target" || return 1; new_moved=1
  fi
  /bin/mv -f -- "$registry_temp" "$registry" || return 1; registry_temp=''; registry_moved=1
  /bin/mv -- "$stage/prior" "$previous" || return 1; previous_published=1
  committed=1
}
commit_changes || fail 'Adapter transaction failed; restoring the previous state.'
print -r -- "Adapter $mode completed. Previous owned state saved at: $previous
Restart native Steam. Select the installed or restored tool in Compatibility. If the tool was removed, select your previous tool.
Other registry entries, runtimes and game prefixes were preserved. No game was launched."
