# Validation — 23 October 2026

Route: **THE FINALS — CrossOver 26.3 — NotProton Steam native**, version **0.1.0-alpha8**.
Host: M5 MacBook Air, macOS 27.0.1 (26A434).

## 0.1.0-alpha8 (27 October 2026)

The structural detector replaces the M5-only hash recipes. It reproduced all 42
previously validated corrections byte-for-byte, accepted two unseen encodings,
loaded all 44 test libraries on arm64 and x86_64, and passed 98 curve/dissolve
render cases. Unsafe patterns, disabled/wrong-process use and Metal rejection
retained the original behavior. A cache scan matched only the 14 known affected
libraries among 18,833 inputs; 20,002 malformed-input checks passed with address
and undefined-behavior sanitizers. These are standalone M5 tests, not M4 gameplay.

This route passed source checks, installation, isolated CPU tests and complete
runtime verification. Adapter/launcher payloads are unchanged from the preceding
release. No new alpha8 gameplay result is claimed. M4 and older chips have not
yet been tested with this release; community reports will establish coverage.
Earlier route-specific gameplay results and limitations remain below.

## 0.1.0-alpha6 (25 October 2026)

S12 skin correction extended to Preview 27.0.0.41073: 14 new recipes captured from an actual Practice Range run on that build (first and third person), all associated by exact original DXIL and passing the two-line proof; the 42-recipe component passed loading on both architectures, 98 rendering cases and all fail-safe guards (`skin-package-validation-20261025-230237`). Not yet checked in-game with this package.

## 0.1.0-alpha5 (25 October 2026)

This version has not been installed or launched yet. Changes: NotProton 1.2.1 launch script (NotProton routes), shorter Steam tool name, shared CPU-fix sources that now recognise both Preview builds. Results below are for the earlier version named in them.

## Earlier result (previous version)

Installer, CPU checks and isolated launcher checks passed. The final integrated package reached Practice Range with the skin correction active; Stable online play remains unvalidated.

## Package checks

- Exact source/dependency checks, installation into a private runtime and complete runtime-receipt verification passed on this Mac.
- Bundled CPU tests passed NT flags, syscalls, exceptions, IRET and child-process checks in an isolated prefix.
- NotProton dry run, installation, verification, identical reinstall, update, rollback, removal and restore-after-removal passed in an isolated tool directory. App-ID, path, argument, graphics and language controls passed; unrelated registry rows were preserved.
- All generated shell scripts passed macOS zsh syntax checks. Component activation preserves the existing CPU/overlay environment; disabled, changed-payload and unexpected-path controls passed.
- The component passed standalone library loading on both architectures for 42 exact shader variants (14 July Preview, 14 Stable, 14 Preview 27.0.0.41073), 196 rendering cases and fail-safe controls. Unknown inputs and rejected corrections retain the original library. Standalone checks do not establish online gameplay.

The user confirmed menu skin and first-person hands during the preceding integrated Stable test. The final 28-variant package then relaunched into Practice Range and applied the corrections. No complete Stable online match has been tested.

## Earlier gameplay evidence

On 16 October, the earlier Stable NotProton package reached the authenticated lobby, passed a user Practice Range check and relaunched. The user explicitly did not test a full online match on Stable. Those results predate S12 and do not establish skin correction coverage.

Results apply only to their stated route and implementation. A second Mac, future game/runtime builds, frame generation and other graphics backends remain unvalidated. Installer or standalone success does not establish online gameplay reliability.
