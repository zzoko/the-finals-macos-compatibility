#!/bin/zsh
# Register one owned CrossOver bottle icon; preserve game files and bottle preferences.
emulate -LR zsh
setopt ERR_EXIT NO_UNSET PIPE_FAIL
umask 077
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
runtime='' bottle='' mode=install
state="$HOME/Library/Application Support/THE FINALS Compatibility/BottleAdapter-Preview-27.0.0.40734"
dry=0 stage='' lock=''
menu_id='StartMenu/Programs/THE FINALS (Patched)'
menu_description='THE FINALS Compatibility launcher'
menu_created=0 committed=0
fail() { print -u2 -r -- "Error: $*"; exit 1; }
sha() { /usr/bin/shasum -a 256 -- "$1" | /usr/bin/awk '{print $1}'; }
no_links() { local p=${1:a}; while [[ $p != / ]]; do [[ ! -L $p ]] || fail "Symbolic-link path refused: $p"; p=${p:h}; done; }
runtime_entrypoint() {
  local p=$1 resolved=${1:A} target
  [[ -f $p && -x $p && $resolved == "$runtime"/* ]] || fail 'Runtime entrypoint must resolve inside the verified runtime.'
  # CrossOver ships bin -> "CrossOver-Hosted Application". Permit that internal
  # layout, but never follow an entrypoint link whose target leaves this copy.
  while [[ $p != "$runtime" ]]; do
    if [[ -L $p ]]; then
      target=$(/usr/bin/readlink "$p")
      [[ $target == /* ]] || target="${p:h}/$target"
      target=${target:a}
      [[ $target == "$runtime"/* ]] || fail 'External runtime entrypoint link refused.'
    fi
    p=${p:h}
  done
}
usage() {
  print -r -- 'Usage: bottle.zsh --runtime PATH --bottle PATH [--state-dir PATH] [--dry-run]
       bottle.zsh --verify|--rollback|--remove [--state-dir PATH]
The core installer must verify the runtime before installation. Adds one THE FINALS (Patched) bottle icon; graphics preferences and games remain intact.'
}
while (( $# )); do
  case $1 in
    --runtime|--bottle|--state-dir)
      (( $# >= 2 )) && [[ -n $2 && $2 != --* ]] || fail "Missing value for $1."
      case $1 in --runtime) runtime=$2 ;; --bottle) bottle=$2 ;; --state-dir) state=$2 ;; esac; shift 2 ;;
    --verify|--rollback|--remove) [[ $mode == install ]] || fail 'Choose one mode.'; mode=${1#--}; shift ;;
    --dry-run) dry=1; shift ;; --help|-h) usage; exit 0 ;; *) fail "Unknown argument: $1" ;;
  esac
done
for p in "$state" "$runtime" "$bottle"; do
  [[ $p != *$'\n'* && $p != *$'\r'* && $p != *$'\t'* ]] || fail 'Paths cannot contain tabs or newlines.'
done
state=${state:a}; no_links "$state"
[[ $state != / && $state != ${HOME:a} ]] || fail 'Unsafe state directory.'
marker='THE FINALS Compatibility bottle adapter v1'
verify() {
  local dir=$1 p
  no_links "$dir"
  [[ -d $dir && -f $dir/.owner && -f $dir/checksums && $(<"$dir/.owner") == $marker ]] || fail "Unowned launcher: $dir"
  for p in "$dir"/*(DN); do
    [[ ! -L $p && -f $p ]] || fail 'Unexpected launcher content.'
    case ${p:t} in .DS_Store|.owner|checksums|'Launch THE FINALS.command'|runtime.txt|bottle.txt|menu-command.txt) ;; *) fail 'Unexpected launcher file.' ;; esac
  done
  [[ -f "$dir/Launch THE FINALS.command" && -f $dir/runtime.txt && -f $dir/bottle.txt ]] || fail 'Incomplete launcher; left untouched.'
  [[ -x "$dir/Launch THE FINALS.command" ]] || fail 'Launcher executable permission changed; left untouched.'
  # Hash the fixed file list ourselves, rather than trusting paths listed by checksums.
  local -a owned=(.owner 'Launch THE FINALS.command' runtime.txt bottle.txt)
  [[ ! -f $dir/menu-command.txt ]] || owned+=(menu-command.txt)
  [[ $(cd "$dir"; /usr/bin/shasum -a 256 $owned) == $(<"$dir/checksums") ]] || fail 'Launcher was edited; left untouched.'
}
# Query only our entry using CrossOver's own parser. Missing section is exit 3.
cxmenu() {
  /usr/bin/env CX_BOTTLE_PATH="${bottle:h}" CX_INITIALIZED="$EUID:${bottle:t}" "$runtime/bin/cxmenu" --bottle "${bottle:t}" --scope private "$@"
}
menu_read() {
  /usr/bin/perl -I"$runtime/lib/perl" -MCXConfig -e '
    my $c=CXConfig->new($ARGV[0]); my $s=$c->get_section($ARGV[1]); exit 3 unless $s;
    print $s->get("Type",""),"\n",$s->get("Command",""),"\n",$s->get("Description","");
  ' "$bottle/cxmenu.conf" "$menu_id"
}
menu_expected() { print -r -- "raw"$'\n'"$1"$'\n'"$menu_description"; }
menu_check() {
  local found code=0
  found=$(menu_read) || code=$?
  (( code == 0 )) || fail 'The THE FINALS bottle icon is missing or cannot be read. Re-run Install / update.'
  [[ $found == "$(menu_expected "$1")" ]] || fail 'The THE FINALS bottle icon was modified; left untouched.'
  local query=$(cxmenu --query --filter "$menu_id")
  [[ $query == *"[$menu_id]"$'\n'"IDs=CXMenuMacOSX/"* ]] || fail 'The THE FINALS icon is not exported to CrossOver. Re-run Install / update.'
}
menu_install() {
  local steam="$bottle/drive_c/Program Files (x86)/Steam" cached
  local -a artwork=()
  # Use the recipient's own cached THE FINALS artwork; distribute no game image.
  for cached in "$steam/appcache/librarycache/2073850"/*.jpg(N); do
    if [[ -f "$steam/steam/games/${cached:t:r}.ico" ]]; then
      artwork=(--icon "$steam/steam/games/${cached:t:r}.ico")
    else
      artwork=(--icon "$cached")
    fi
    break
  done
  cxmenu --create "$menu_id" --type raw \
    --description "$menu_description" --command "$1" "${artwork[@]}" --install
  menu_check "$1"
}
menu_remove() {
  cxmenu --uninstall --delete --filter "$menu_id"
}
cleanup() {
  if (( menu_created && ! committed )); then ( menu_remove ) || print -u2 -- 'Could not remove the new bottle entry after failure.'; fi
  [[ -z $stage || ! -d $stage ]] || /bin/rm -rf -- "$stage"; [[ -z $lock ]] || /bin/rmdir -- "$lock"; }
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
if [[ -d $state ]]; then
  [[ -f $state/.owner && ! -L $state/.owner && $(<"$state/.owner") == $marker ]] || fail 'State directory is not owned by this adapter.'
  for p in "$state"/*(DN); do
    [[ ! -L $p ]] || fail 'Unexpected symlink in state.'
    if [[ ${p:t} == .DS_Store ]]; then [[ -f $p ]] || fail 'Unexpected Finder metadata type.'; continue; fi
    case ${p:t} in .owner|current|previous|removed) ;; *) fail 'Unexpected state content.' ;; esac
  done
fi
if [[ $mode != install ]]; then
  verify "$state/current"
    runtime=$(<"$state/current/runtime.txt"); bottle=$(<"$state/current/bottle.txt")
  if [[ -f $state/current/menu-command.txt ]]; then menu_check "$(<"$state/current/menu-command.txt")"; fi
  if [[ $mode == verify ]]; then print -r -- "Verified THE FINALS bottle launcher: $bottle"; exit 0; fi
  [[ $mode != rollback ]] || verify "$state/previous"
  (( ! dry )) || { print -r -- "Would $mode the owned bottle launcher; bottle and runtimes remain intact."; exit 0; }
  /bin/mkdir "$state.lock" || fail 'Adapter is busy.'; lock="$state.lock"
  if [[ $mode == rollback ]]; then
    /bin/mv "$state/current" "$state/.swap"
    /bin/mv "$state/previous" "$state/current" || { /bin/mv "$state/.swap" "$state/current"; fail 'Rollback failed.'; }
    /bin/mv "$state/.swap" "$state/previous"
    runtime=$(<"$state/current/runtime.txt"); bottle=$(<"$state/current/bottle.txt")
    if [[ -f $state/current/menu-command.txt ]]; then menu_install "$(<"$state/current/menu-command.txt")"
    else menu_remove; fi
    print -r -- "Restored previous launcher: $state/current/Launch THE FINALS.command"
  else
    [[ ! -e $state/removed ]] || fail 'A removed launcher is already archived; move it elsewhere before removing again.'
    /bin/mv "$state/current" "$state/removed"
    if [[ -f $state/removed/menu-command.txt ]] && ! ( menu_remove ); then
      /bin/mv "$state/removed" "$state/current"
      fail 'Could not remove the bottle icon; launcher restored.'
    fi
    print -r -- 'Launcher removed and archived; bottle and runtime copies were preserved.'
  fi
  exit 0
fi
[[ -n $runtime && -n $bottle ]] || { usage; exit 1; }
runtime=${runtime:a}; bottle=${bottle:a}; no_links "$runtime"; no_links "$bottle"
for p in "$runtime" "$bottle"; do
  [[ $state != "$p" && $state != "$p"/* && $p != "$state"/* ]] || fail 'State directory must be separate from the bottle and runtime trees.'
done
runtime_entrypoint "$runtime/bin/wine"
[[ -f $bottle/cxbottle.conf && ! -L $bottle/cxbottle.conf ]] || fail 'A normal CrossOver bottle is required.'
/usr/bin/grep -Eq '^"WineArch"[[:space:]]*=[[:space:]]*"win64"' "$bottle/cxbottle.conf" || fail 'A 64-bit CrossOver bottle is required.'
if /usr/bin/grep -Eq '^"(BinPath|LibPath|DllPath|CX_ROOT|ARC_[A-Z0-9_]+)"[[:space:]]*=' "$bottle/cxbottle.conf"; then
  fail 'This bottle overrides runtime paths or ARC compatibility internals. Remove those custom overrides first; ordinary graphics preferences are supported.'
fi
no_links "$bottle/drive_c/Program Files (x86)/Steam/Steam.exe"
[[ -f "$bottle/drive_c/Program Files (x86)/Steam/Steam.exe" ]] || fail 'Windows Steam is not installed at its standard location in this bottle.'
/usr/bin/grep -Eq '^"Preview"[[:space:]]*=[[:space:]]*"1"' "$bottle/cxbottle.conf" || fail 'Select a bottle created or imported by the matching CrossOver Preview app. Stable bottles cannot be launched directly by Preview.'
typeset -a rels=('lib/arc-preview/finals-regions.dylib' 'lib/arc-nt/runtime_loader' 'lib/arc-nt/libRuntimeRosettax87' 'lib/wine/x86_64-unix/wine' 'lib/wine/x86_64-unix/wine-nt-original' 'lib/wine/x86_64-windows/ntdll-arc.dll') hashes=()
for p in $rels; do no_links "$runtime/$p"; [[ -f $runtime/$p ]] || fail "Missing $p"; hashes+=("$(sha "$runtime/$p")"); done
[[ ! -e $state/current ]] || verify "$state/current"
[[ ! -e $state/previous ]] || verify "$state/previous"
if [[ -d $state/current ]]; then
  [[ $(<"$state/current/bottle.txt") == "$bottle" ]] || fail 'Remove the existing THE FINALS launcher before choosing another bottle.'
fi
# Refuse an unrelated/customized entry with the same name.
menu_command="/bin/zsh ${(qq)state}/current/'Launch THE FINALS.command'"
menu_before=''; menu_status=0
menu_before=$(menu_read) || menu_status=$?
if (( menu_status == 0 )); then
  [[ -f $state/current/menu-command.txt && $menu_before == "$(menu_expected "$(<"$state/current/menu-command.txt")")" ]] || fail 'An unowned or edited THE FINALS (Patched) bottle icon already exists.'
elif (( menu_status != 3 )); then
  fail 'Cannot inspect the bottle menu.'
fi
(( ! dry )) || { print -r -- "Would add THE FINALS (Patched) inside $bottle using $runtime"; exit 0; }
/bin/mkdir -p "${state:h}"
/bin/mkdir "$state.lock" || fail 'Adapter is busy.'; lock="$state.lock"
[[ -d $state ]] || { /bin/mkdir "$state"; print -r -- "$marker" > "$state/.owner"; }
stage=$(/usr/bin/mktemp -d "$state/.stage.XXXXXXXX")
print -r -- "$marker" > "$stage/.owner"
print -r -- "$runtime" > "$stage/runtime.txt"
print -r -- "$bottle" > "$stage/bottle.txt"
print -r -- "$menu_command" > "$stage/menu-command.txt"
{
  print -r -- '#!/bin/zsh
emulate -LR zsh
setopt ERR_EXIT NO_UNSET PIPE_FAIL
export PATH=/usr/bin:/bin:/usr/sbin:/sbin'
  print -r -- "runtime=${(qq)runtime}"
  print -r -- "bottle=${(qq)bottle}"
  for (( i=1; i<=${#rels}; ++i )); do
    print -r -- "[[ \$(/usr/bin/shasum -a 256 -- \"\$runtime/${rels[i]}\" | /usr/bin/awk '{print \$1}') == ${hashes[i]} ]] || { print -u2 'Runtime changed. Re-run the installer to verify it.'; exit 1; }"
  done
  print -r -- '# Clear inherited optional flags; CrossOver reads the selected bottle preferences.
unset CX_GRAPHICS_BACKEND D3DM_ENABLE_METALFX DXMT_ENABLE_NVEXT DXMT_CONFIG MTL_HUD_ENABLED WINEMSYNC ROSETTA_ADVERTISE_AVX
export ARC_NATIVE_CODE_REGIONS=1 WINEDEBUG=-all
export ARC_NT_USE_AOT=1 ROSETTA_ADVERTISE_AVX=0
export ARC_NT_WINE_DIR="$runtime/lib/wine/x86_64-unix"
export ARC_PREVIEW_CODE_REGIONS=1
export ARC_PREVIEW_NTDLL_PATH="$runtime/lib/wine/x86_64-windows/ntdll-arc.dll"
export ARC_NT_LAB_TARGET_DYLD="$runtime/lib/arc-preview/finals-regions.dylib"
export CX_APPLEGPTK_LIBD3DSHARED_PATH="$runtime/lib/apple_gptk/external/libd3dshared.dylib"
export D3DMETAL_FRAMEWORK_PATH="$runtime/lib/apple_gptk/external/D3DMetal.framework/D3DMetal"
unset CX_BOTTLE WINEPREFIX WINEDLLPATH WINELOADER WINESERVER CX_INITIALIZED
print -r -- "Starting THE FINALS with the private compatibility runtime."
exec "$runtime/bin/wine" --bottle "$bottle" --no-update --debugmsg -all --wait \
  '\''C:\Program Files (x86)\Steam\Steam.exe'\'' -applaunch 2073850 -culture=en'
} > "$stage/Launch THE FINALS.command"
/bin/chmod 700 "$stage/Launch THE FINALS.command"
/bin/zsh -n "$stage/Launch THE FINALS.command"
( cd "$stage"; /usr/bin/shasum -a 256 .owner 'Launch THE FINALS.command' runtime.txt bottle.txt menu-command.txt > checksums )
if [[ -d $state/current && $(<"$stage/checksums") == $(<"$state/current/checksums") ]]; then
  menu_install "$menu_command"
  print -r -- "Already configured: THE FINALS (Patched) inside $bottle"; exit 0
fi
# Install/verify the menu first. It points to the stable current launcher path.
# A failed file commit leaves the previous launcher available; new entries roll back.
(( menu_status != 3 )) || menu_created=1
( menu_install "$menu_command" ) || fail 'Could not install the bottle icon.'
if [[ -d $state/current ]]; then
  [[ ! -d $state/previous ]] || /bin/rm -rf -- "$state/previous"
  /bin/mv "$state/current" "$state/previous"
fi
/bin/mv "$stage" "$state/current" || { [[ ! -d $state/previous ]] || /bin/mv "$state/previous" "$state/current"; fail 'Could not commit launcher.'; }
stage=''
committed=1
print -r -- "Ready: reopen CrossOver to refresh its launchers, select the bottle, then double-click THE FINALS (Patched)."
print -r -- 'Set graphics preferences in CrossOver. Close other apps in that bottle before launching or switching runtimes.'
