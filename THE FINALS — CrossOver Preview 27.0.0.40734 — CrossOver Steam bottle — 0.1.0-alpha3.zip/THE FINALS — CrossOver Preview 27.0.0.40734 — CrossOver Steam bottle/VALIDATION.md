# Validation — 23 October 2026

Route: **THE FINALS — CrossOver Preview 27.0.0.40734 — CrossOver Steam bottle**, version **0.1.0-alpha3**.
Host: M5 MacBook Air, macOS 27.0.1 (26A434).

## Current result

Installer, CPU checks and isolated menu lifecycle checks passed. The actual game-launch test crashed before Windows Steam started; this bottle route is not validated for gameplay.

## Package checks

- Exact source/dependency checks, installation into a private runtime and complete runtime-receipt verification passed on this Mac.
- Bundled CPU tests passed NT flags, syscalls, exceptions, IRET and child-process checks in an isolated prefix.
- CrossOver icon registration, verification, identical reinstall, update, rollback and removal passed in an isolated bottle. Actual `cxmenu` launch used a harmless marker, not THE FINALS. Existing menu entries, artwork and graphics preferences were preserved.
- All generated shell scripts passed macOS zsh syntax checks. Component activation preserves the existing CPU/overlay environment; disabled, changed-payload and unexpected-path controls passed.
- The component passed standalone library loading on both architectures for 28 exact shader variants (14 Preview and 14 Stable), 196 rendering cases and fail-safe controls. Unknown inputs and rejected corrections retain the original library. Standalone checks do not establish online gameplay.

## Actual launch attempt

Launching the owned CrossOver icon with the final package exited with SIGSEGV before Windows Steam or THE FINALS opened. The crash occurred during Wine startup (`init_startup_info`). The harmless menu-marker test above therefore does not establish a working game launch. No S12 gameplay result is claimed for this bottle route.

## Earlier gameplay evidence

An earlier private Preview Windows Steam setup completed an online match on 16 October. That was not a S12 gameplay test of this integrated CrossOver bottle package.

Results apply only to their stated route and implementation. A second Mac, future game/runtime builds, frame generation and other graphics backends remain unvalidated. Installer or standalone success does not establish online gameplay reliability.
