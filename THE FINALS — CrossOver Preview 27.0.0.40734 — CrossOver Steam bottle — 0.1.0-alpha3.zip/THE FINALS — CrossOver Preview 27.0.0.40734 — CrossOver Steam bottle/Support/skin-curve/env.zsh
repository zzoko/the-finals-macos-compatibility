# Sourced by the game launcher. This module may be retired independently of CPU compatibility.
if [[ ${FINALS_SKIN_CURVE:-1} == 0 ]]; then
  export D3DM_FINALS_SKIN_CURVE=0
  return 0
fi
typeset finals_skin_root=${${(%):-%x}:A:h}
typeset finals_skin_library="$finals_skin_root/finals-skin-curve.dylib"
if [[ ! -f $finals_skin_library || -L $finals_skin_library || $(/usr/bin/shasum -a 256 -- "$finals_skin_library" | /usr/bin/awk '{print $1}') != f192e9d39af470124c8cec1a58d926923e07372d9017b057da83943567f7b7ad ]]; then
  print -u2 -r -- 'The S12 skin correction changed or is missing. Run Install.command → Verify.'
  return 1
fi
# NotProton forwards D3DM_* through its macOS application launch environment.
export D3DM_FINALS_SKIN_CURVE=1
if (( ${+FINALS_SKIN_CURVE_LOG} )); then
  export D3DM_FINALS_SKIN_CURVE_LOG="$FINALS_SKIN_CURVE_LOG"
fi
case ${1:-} in
  notproton)
    case ":${STEAM_DYLD_INSERT_LIBRARIES:-}:" in
      *":$finals_skin_library:"*) ;;
      *) export STEAM_DYLD_INSERT_LIBRARIES="$finals_skin_library${STEAM_DYLD_INSERT_LIBRARIES:+:$STEAM_DYLD_INSERT_LIBRARIES}" ;;
    esac ;;
  bottle)
    # The CPU loader restores this list only for its selected game process.
    # Preserve Preview's code-region helper and any existing overlay libraries.
    typeset -a finals_skin_chain=()
    typeset finals_skin_entry
    for finals_skin_entry in "${(@s/:/)${ARC_NT_LAB_TARGET_DYLD:-}}" "${(@s/:/)${DYLD_INSERT_LIBRARIES:-}}" "$finals_skin_library"; do
      [[ -n $finals_skin_entry ]] || continue
      (( ${finals_skin_chain[(Ie)$finals_skin_entry]} )) || finals_skin_chain+=("$finals_skin_entry")
    done
    export ARC_NT_LAB_TARGET_DYLD="${(j/:/)finals_skin_chain}"
    # A nonempty inherited DYLD list takes precedence in the existing CPU entry.
    # Keep an existing list consistent; otherwise leave DYLD unset here.
    if [[ -n ${DYLD_INSERT_LIBRARIES:-} ]]; then
      export DYLD_INSERT_LIBRARIES="$ARC_NT_LAB_TARGET_DYLD"
    fi
    unset finals_skin_chain finals_skin_entry ;;
  *) print -u2 -r -- 'Unsupported skin correction launch method.'; return 1 ;;
esac
unset finals_skin_root finals_skin_library
