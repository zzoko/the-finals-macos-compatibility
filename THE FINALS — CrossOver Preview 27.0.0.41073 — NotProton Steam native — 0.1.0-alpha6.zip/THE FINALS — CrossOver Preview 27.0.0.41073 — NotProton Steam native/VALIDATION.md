# Validation — 23 October 2026

Route: **THE FINALS — CrossOver Preview 27.0.0.41073 — NotProton Steam native**, version **0.1.0-alpha6**.
Host: M5 MacBook Air, macOS 27.0.1 (26A434).

## 0.1.0-alpha6 (25 October 2026)

S12 skin correction extended to Preview 27.0.0.41073: 14 new recipes captured from an actual Practice Range run on that build (first and third person), all associated by exact original DXIL and passing the two-line proof; the 42-recipe component passed loading on both architectures, 98 rendering cases and all fail-safe guards (`skin-package-validation-20261025-230237`). Checked in-game with this package on 25 October 2026: exposed arms render correctly in first and third person (menu and Practice Range), ray tracing off.

## 0.1.0-alpha5 (25 October 2026)

Tested 25 October 2026: installed (CPU check passed) and launched. With `D3DM_SUPPORT_DXR=1` the game crashed when entering the Practice Range, so ray tracing stays off. The S12 skin correction does not apply on this Preview build: its shaders differ from the July build's, so exposed arms are not corrected (the original behavior is kept). Recipes for this build still have to be captured. Changes: NotProton 1.2.1 launch script (NotProton routes), shorter Steam tool name, shared CPU-fix sources that now recognise both Preview builds, retarget to Preview 27.0.0.41073 and ray tracing off. Results below are for the earlier version named in them.

## Earlier result (previous version)

Installer, CPU checks and launcher checks passed. A normal Steam relaunch of this integrated package reached the menu with exposed arms visible. No new full online match was tested with this package.

## Package checks

- Exact source/dependency checks, installation into a private runtime and complete runtime-receipt verification passed on this Mac.
- Bundled CPU tests passed NT flags, syscalls, exceptions, IRET and child-process checks in an isolated prefix.
- NotProton dry run, installation, verification, identical reinstall, update, rollback, removal and restore-after-removal passed in an isolated tool directory. App-ID, path, argument, graphics and language controls passed; unrelated registry rows were preserved.
- All generated shell scripts passed macOS zsh syntax checks. Component activation preserves the existing CPU/overlay environment; disabled, changed-payload and unexpected-path controls passed.
- The component passed standalone library loading on both architectures for 42 exact shader variants (14 July Preview, 14 Stable, 14 Preview 27.0.0.41073), 196 rendering cases and fail-safe controls. Unknown inputs and rejected corrections retain the original library. Standalone checks do not establish online gameplay.

The final alpha4 daily tool launched through native macOS Steam and NotProton. Both bare arms were visible at 2940×1912 with MetalFX and GPTK 4.0b1. The running game loaded the packaged alpha4 skin component; the private add-on was absent. This is a menu relaunch check. The earlier Practice Range, cloak, respawn and full-match results below apply to the preceding private correction.

## Earlier gameplay evidence

On 23 October, the preceding local correction restored exposed skin in the menu and Practice Range; the user confirmed cloak and respawn behaved correctly, followed by a normal NotProton Steam relaunch and a full match without errors. That local add-on loaded prepared shader replacements; this package reconstructs them from matching inputs at runtime, so that earlier full-match result is kept separate from this package’s menu relaunch check. One earlier rejected session and one unexplained exit were not reproduced in the successful tests.

Results apply only to their stated route and implementation. A second Mac, future game/runtime builds, frame generation and other graphics backends remain unvalidated. Installer or standalone success does not establish online gameplay reliability.
